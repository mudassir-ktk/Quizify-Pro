<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @since      1.0.0
 *
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/admin
 */

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and hooks for
 * the admin area of the site.
 *
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/admin
 * @author     NetworkUstad Team
 */
class Quizify_Admin {

    /**
     * Initialize the class.
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Nothing to do here
    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {
        $screen = get_current_screen();
        
        // Only load on Quizify admin pages
        if (!$screen || !in_array($screen->id, array('quizify_quiz', 'edit-quizify_quiz', 'quizify_quiz_page_quizify-analytics'))) {
            return;
        }
        
        wp_enqueue_style(
            'quizify-admin',
            QUIZIFY_PRO_PLUGIN_URL . 'admin/css/quizify-admin.css',
            array(),
            QUIZIFY_PRO_VERSION
        );
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {
        $screen = get_current_screen();
        
        // Only load on Quizify admin pages
        if (!$screen || !in_array($screen->id, array('quizify_quiz', 'edit-quizify_quiz', 'quizify_quiz_page_quizify-analytics'))) {
            return;
        }
        
        // Enqueue scripts for quiz editor
        if ($screen->id === 'quizify_quiz') {
            wp_enqueue_script('jquery-ui-sortable');
            wp_enqueue_media();
            
            wp_enqueue_script(
                'quizify-admin',
                QUIZIFY_PRO_PLUGIN_URL . 'admin/js/quizify-admin.js',
                array('jquery', 'jquery-ui-sortable'),
                QUIZIFY_PRO_VERSION,
                true
            );
            
            wp_localize_script(
                'quizify-admin',
                'quizify_admin',
                array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('quizify_admin_nonce'),
                    'i18n' => array(
                        'confirm_delete' => __('Are you sure you want to delete this question?', 'quizify-pro'),
                        'min_options' => __('A question must have at least 2 options.', 'quizify-pro'),
                        'saving' => __('Saving...', 'quizify-pro'),
                        'saved' => __('Saved!', 'quizify-pro'),
                        'error' => __('Error saving.', 'quizify-pro')
                    ),
                    'strings' => array(
                        'correct' => __('Correct', 'quizify-pro')
                    )
                )
            );
        }
        
        // Enqueue scripts for analytics dashboard
        if ($screen->id === 'quizify_quiz_page_quizify-analytics') {
            // Enqueue jQuery UI for datepicker
            wp_enqueue_script('jquery-ui-datepicker');
            wp_enqueue_style('jquery-ui', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
            
            // Enqueue Chart.js for analytics
            wp_enqueue_script(
                'chart-js',
                'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js',
                array('jquery'),
                '3.9.1',
                true
            );
            
            // Enqueue analytics script
            wp_enqueue_script(
                'quizify-analytics',
                QUIZIFY_PRO_PLUGIN_URL . 'admin/js/quizify-analytics.js',
                array('jquery', 'jquery-ui-datepicker', 'chart-js'),
                QUIZIFY_PRO_VERSION,
                true
            );
            
            wp_localize_script(
                'quizify-analytics',
                'quizify_admin',
                array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('quizify_admin_nonce'),
                    'i18n' => array(
                        'no_data' => __('No data available for the selected criteria.', 'quizify-pro'),
                        'loading' => __('Loading data...', 'quizify-pro'),
                        'error' => __('Error loading data. Please try again.', 'quizify-pro')
                    )
                )
            );
        }
    }

    /**
     * Register the post type.
     *
     * @since    1.0.0
     */
    public function register_post_type() {
        $labels = array(
            'name'                  => _x('Quizzes', 'Post type general name', 'quizify-pro'),
            'singular_name'         => _x('Quiz', 'Post type singular name', 'quizify-pro'),
            'menu_name'             => _x('Quizify', 'Admin Menu text', 'quizify-pro'),
            'name_admin_bar'        => _x('Quiz', 'Add New on Toolbar', 'quizify-pro'),
            'add_new'               => __('Add New', 'quizify-pro'),
            'add_new_item'          => __('Add New Quiz', 'quizify-pro'),
            'new_item'              => __('New Quiz', 'quizify-pro'),
            'edit_item'             => __('Edit Quiz', 'quizify-pro'),
            'view_item'             => __('View Quiz', 'quizify-pro'),
            'all_items'             => __('All Quizzes', 'quizify-pro'),
            'search_items'          => __('Search Quizzes', 'quizify-pro'),
            'parent_item_colon'     => __('Parent Quizzes:', 'quizify-pro'),
            'not_found'             => __('No quizzes found.', 'quizify-pro'),
            'not_found_in_trash'    => __('No quizzes found in Trash.', 'quizify-pro')
        );
        
        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array('slug' => 'quiz'),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'menu_icon'          => 'dashicons-clipboard',
            'supports'           => array('title', 'editor', 'thumbnail')
        );
        
        register_post_type('quizify_quiz', $args);
    }

    /**
     * Add admin menu items.
     *
     * @since    1.0.0
     */
    public function add_admin_menu() {
        add_submenu_page(
            'edit.php?post_type=quizify_quiz',
            __('Settings', 'quizify-pro'),
            __('Settings', 'quizify-pro'),
            'manage_options',
            'quizify-settings',
            array($this, 'render_settings_page')
        );
        
        add_submenu_page(
            'edit.php?post_type=quizify_quiz',
            __('License', 'quizify-pro'),
            __('License', 'quizify-pro'),
            'manage_options',
            'quizify-license',
            array($this, 'render_license_page')
        );
    }

    /**
     * Register meta boxes.
     *
     * @since    1.0.0
     */
    public function add_meta_boxes() {
        add_meta_box(
            'quizify_quiz_settings',
            __('Quiz Settings', 'quizify-pro'),
            array($this, 'render_settings_meta_box'),
            'quizify_quiz',
            'normal',
            'high'
        );
        
        add_meta_box(
            'quizify_quiz_questions',
            __('Quiz Questions', 'quizify-pro'),
            array($this, 'render_questions_meta_box'),
            'quizify_quiz',
            'normal',
            'high'
        );
        
        add_meta_box(
            'quizify_quiz_shortcode',
            __('Shortcode', 'quizify-pro'),
            array($this, 'render_shortcode_meta_box'),
            'quizify_quiz',
            'side',
            'default'
        );
    }

    /**
     * Render settings meta box.
     *
     * @since    1.0.0
     * @param    WP_Post    $post    The post object.
     */
    public function render_settings_meta_box($post) {
        // Add nonce for security
        wp_nonce_field('quizify_save_meta', 'quizify_meta_nonce');
        
        // Get meta values
        $time_limit = get_post_meta($post->ID, 'quizify_time_limit', true);
        $passing_score = get_post_meta($post->ID, 'quizify_passing_score', true);
        $randomize_questions = get_post_meta($post->ID, 'quizify_randomize_questions', true);
        $randomize_answers = get_post_meta($post->ID, 'quizify_randomize_answers', true);
        $pass_message = get_post_meta($post->ID, 'quizify_pass_message', true);
        $fail_message = get_post_meta($post->ID, 'quizify_fail_message', true);
        $show_results = get_post_meta($post->ID, 'quizify_show_results', true);
        $difficulty = get_post_meta($post->ID, 'quizify_difficulty', true);
        
        // Set defaults
        if (!$passing_score) {
            $settings = get_option('quizify_settings', array());
            $passing_score = isset($settings['default_passing_score']) ? $settings['default_passing_score'] : 70;
        }
        
        // Output HTML
        ?>
        <div class="quizify-meta-box-container">
            <div class="quizify-field-row">
                <div class="quizify-field">
                    <label for="quizify_time_limit"><?php _e('Time Limit (minutes)', 'quizify-pro'); ?></label>
                    <input type="number" id="quizify_time_limit" name="quizify_time_limit" value="<?php echo esc_attr($time_limit); ?>" min="0" step="1">
                    <p class="description"><?php _e('Set to 0 for no time limit.', 'quizify-pro'); ?></p>
                </div>
                
                <div class="quizify-field">
                    <label for="quizify_passing_score"><?php _e('Passing Score (%)', 'quizify-pro'); ?></label>
                    <input type="number" id="quizify_passing_score" name="quizify_passing_score" value="<?php echo esc_attr($passing_score); ?>" min="0" max="100" step="1">
                </div>
                
                <div class="quizify-field">
                    <label for="quizify_difficulty"><?php _e('Quiz Difficulty', 'quizify-pro'); ?></label>
                    <select id="quizify_difficulty" name="quizify_difficulty">
                        <option value="beginner" <?php selected($difficulty, 'beginner'); ?>><?php _e('Beginner', 'quizify-pro'); ?></option>
                        <option value="intermediate" <?php selected($difficulty, 'intermediate'); ?>><?php _e('Intermediate', 'quizify-pro'); ?></option>
                        <option value="advanced" <?php selected($difficulty, 'advanced'); ?>><?php _e('Advanced', 'quizify-pro'); ?></option>
                        <option value="expert" <?php selected($difficulty, 'expert'); ?>><?php _e('Expert', 'quizify-pro'); ?></option>
                    </select>
                    <p class="description"><?php _e('This will be displayed to users before they start the quiz.', 'quizify-pro'); ?></p>
                </div>
            </div>
            
            <div class="quizify-field-row">
                <div class="quizify-field">
                    <label>
                        <input type="checkbox" name="quizify_randomize_questions" value="1" <?php checked($randomize_questions, '1'); ?>>
                        <?php _e('Randomize Questions', 'quizify-pro'); ?>
                    </label>
                </div>
                
                <div class="quizify-field">
                    <label>
                        <input type="checkbox" name="quizify_randomize_answers" value="1" <?php checked($randomize_answers, '1'); ?>>
                        <?php _e('Randomize Answers', 'quizify-pro'); ?>
                    </label>
                </div>
                
                <div class="quizify-field">
                    <label>
                        <input type="checkbox" name="quizify_show_results" value="1" <?php checked($show_results, '1'); ?>>
                        <?php _e('Show Detailed Results', 'quizify-pro'); ?>
                    </label>
                </div>
            </div>
            
            <div class="quizify-field-row">
                <div class="quizify-field">
                    <label for="quizify_pass_message"><?php _e('Pass Message', 'quizify-pro'); ?></label>
                    <textarea id="quizify_pass_message" name="quizify_pass_message" rows="3" style="width: 100%;"><?php echo esc_textarea($pass_message); ?></textarea>
                    <p class="description"><?php _e('Message displayed when quiz is passed.', 'quizify-pro'); ?></p>
                </div>
                
                <div class="quizify-field">
                    <label for="quizify_fail_message"><?php _e('Fail Message', 'quizify-pro'); ?></label>
                    <textarea id="quizify_fail_message" name="quizify_fail_message" rows="3" style="width: 100%;"><?php echo esc_textarea($fail_message); ?></textarea>
                    <p class="description"><?php _e('Message displayed when quiz is failed.', 'quizify-pro'); ?></p>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render questions meta box.
     *
     * @since    1.0.0
     * @param    WP_Post    $post    The post object.
     */
    public function render_questions_meta_box($post) {
        // Get questions
        $questions = get_post_meta($post->ID, 'quizify_questions', true);
        if (!is_array($questions)) {
            $questions = array();
        }
        
        // Output HTML
        ?>
        <div class="quizify-quiz-builder">
            <div class="quizify-questions" data-quiz-id="<?php echo $post->ID; ?>">
                <?php
                if (!empty($questions)) {
                    foreach ($questions as $index => $question) {
                        $this->render_question($index, $question);
                    }
                }
                ?>
            </div>
            
            <div class="quizify-actions">
                <button type="button" class="button button-primary quizify-add-question-button"><?php _e('Add Question', 'quizify-pro'); ?></button>
            </div>
            
            <div class="quizify-question-template" style="display:none;">
                <?php
                // Default question template
                $template_question = array(
                    'text' => '',
                    'type' => 'single',
                    'options' => array(
                        array('text' => '', 'correct' => false),
                        array('text' => '', 'correct' => false)
                    )
                );
                $this->render_question('{{index}}', $template_question, true);
                ?>
            </div>
            
            <!-- Template for new options -->
            <div class="quizify-option-template" style="display:none;">
                <div class="quizify-option-item">
                    <div class="quizify-option-handle">
                        <span class="dashicons dashicons-menu"></span>
                    </div>
                    <div class="quizify-option-content">
                        <input type="text" name="quizify_questions[{{questionIndex}}][options][{{optionIndex}}][text]" value="" placeholder="<?php esc_attr_e('Option text', 'quizify-pro'); ?>">
                    </div>
                    <div class="quizify-option-correct">
                        <!-- Single choice (radio button) -->
                        <label class="quizify-correct-radio-label">
                            <input type="radio" name="quizify_questions[{{questionIndex}}][correct]" value="{{optionIndex}}" class="quizify-correct-radio">
                            <?php _e('Correct', 'quizify-pro'); ?>
                        </label>
                        <!-- Multiple choice (checkbox) -->
                        <label style="display:none;" class="quizify-correct-checkbox-label">
                            <input type="checkbox" name="quizify_questions[{{questionIndex}}][options][{{optionIndex}}][correct]" value="1" class="quizify-correct-checkbox">
                            <?php _e('Correct', 'quizify-pro'); ?>
                        </label>
                    </div>
                    <div class="quizify-option-actions">
                        <button type="button" class="button quizify-remove-option-button"><?php _e('Remove', 'quizify-pro'); ?></button>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render a question.
     *
     * @since    1.0.0
     * @param    int|string    $index          The question index.
     * @param    array         $question       The question data.
     * @param    bool          $is_template    Whether this is a template.
     */
    private function render_question($index, $question, $is_template = false) {
        $question_type = isset($question['type']) ? $question['type'] : 'single';
        $question_text = isset($question['text']) ? $question['text'] : '';
        $question_image = isset($question['image_url']) ? $question['image_url'] : '';
        $question_options = isset($question['options']) ? $question['options'] : array(
            array('text' => '', 'correct' => false),
            array('text' => '', 'correct' => false)
        );
        
        // Make sure we have at least 2 options for new questions/templates
        // But don't add empty options for existing questions that are being edited
        if ($is_template || empty($question_options)) {
            while (count($question_options) < 2) {
                $question_options[] = array('text' => '', 'correct' => false);
            }
        }
        ?>
        <div class="quizify-question" data-index="<?php echo esc_attr($index); ?>">
            <div class="quizify-question-header">
                <div class="quizify-question-handle">
                    <span class="dashicons dashicons-menu"></span>
                </div>
                <div class="quizify-question-title">
                    <?php echo $question_text ? esc_html($question_text) : __('New Question', 'quizify-pro'); ?>
                </div>
                <div class="quizify-question-actions">
                    <button type="button" class="button quizify-toggle-question"><?php _e('Edit', 'quizify-pro'); ?></button>
                    <button type="button" class="button quizify-remove-question-button"><?php _e('Remove', 'quizify-pro'); ?></button>
                </div>
            </div>
            
            <div class="quizify-question-content" style="<?php echo $is_template ? '' : 'display:none;'; ?>">
                <div class="quizify-field">
                    <label for="quizify_question_<?php echo esc_attr($index); ?>_text"><?php _e('Question Text', 'quizify-pro'); ?></label>
                    <textarea id="quizify_question_<?php echo esc_attr($index); ?>_text" name="quizify_questions[<?php echo esc_attr($index); ?>][text]" class="quizify-question-text" rows="3"><?php echo esc_textarea($question_text); ?></textarea>
                </div>
                
                <div class="quizify-field">
                    <label for="quizify_question_<?php echo esc_attr($index); ?>_type"><?php _e('Question Type', 'quizify-pro'); ?></label>
                    <select id="quizify_question_<?php echo esc_attr($index); ?>_type" name="quizify_questions[<?php echo esc_attr($index); ?>][type]" class="quizify-question-type">
                        <option value="single" <?php selected($question_type, 'single'); ?>><?php _e('Single Choice', 'quizify-pro'); ?></option>
                        <option value="multiple" <?php selected($question_type, 'multiple'); ?>><?php _e('Multiple Choice', 'quizify-pro'); ?></option>
                    </select>
                </div>
                
                <div class="quizify-field">
                    <label><?php _e('Question Image (Optional)', 'quizify-pro'); ?></label>
                    <div class="quizify-question-image-container">
                        <div class="quizify-image-field">
                            <input type="text" name="quizify_questions[<?php echo esc_attr($index); ?>][image_url]" class="quizify-question-image-url" value="<?php echo esc_attr($question_image); ?>" placeholder="<?php esc_attr_e('Image URL', 'quizify-pro'); ?>">
                            <button type="button" class="button quizify-media-upload-button" data-question="<?php echo esc_attr($index); ?>"><?php _e('Upload Image', 'quizify-pro'); ?></button>
                        </div>
                        <div class="quizify-image-preview">
                            <?php if ($question_image): ?>
                                <img src="<?php echo esc_url($question_image); ?>" alt="Question Image" style="max-width: 200px; max-height: 200px; margin-top: 10px;">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="quizify-field">
                    <label><?php _e('Answer Options', 'quizify-pro'); ?></label>
                    <div class="quizify-options-list">
                        <?php foreach ($question_options as $opt_index => $option): ?>
                            <div class="quizify-option-item">
                                <div class="quizify-option-handle">
                                    <span class="dashicons dashicons-menu"></span>
                                </div>
                                <div class="quizify-option-content">
                                    <input type="text" name="quizify_questions[<?php echo esc_attr($index); ?>][options][<?php echo esc_attr($opt_index); ?>][text]" value="<?php echo esc_attr($option['text']); ?>" placeholder="<?php esc_attr_e('Option text', 'quizify-pro'); ?>">
                                </div>
                                <div class="quizify-option-correct">
                                    <?php if ($question_type === 'single'): ?>
                                        <label>
                                            <input type="radio" name="quizify_questions[<?php echo esc_attr($index); ?>][correct]" value="<?php echo esc_attr($opt_index); ?>" <?php checked(isset($option['correct']) && $option['correct']); ?>>
                                            <?php _e('Correct', 'quizify-pro'); ?>
                                        </label>
                                    <?php else: ?>
                                        <label>
                                            <input type="checkbox" name="quizify_questions[<?php echo esc_attr($index); ?>][options][<?php echo esc_attr($opt_index); ?>][correct]" value="1" <?php checked(isset($option['correct']) && $option['correct']); ?>>
                                            <?php _e('Correct', 'quizify-pro'); ?>
                                        </label>
                                    <?php endif; ?>
                                </div>
                                <div class="quizify-option-actions">
                                    <button type="button" class="button quizify-remove-option-button"><?php _e('Remove', 'quizify-pro'); ?></button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <button type="button" class="button quizify-add-option-button"><?php _e('Add Option', 'quizify-pro'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render shortcode meta box.
     *
     * @since    1.0.0
     * @param    WP_Post    $post    The post object.
     */
    public function render_shortcode_meta_box($post) {
        ?>
        <div class="quizify-shortcode-wrap">
            <div class="quizify-shortcode">[quizify id="<?php echo $post->ID; ?>"]</div>
            <button type="button" class="button quizify-copy-shortcode"><?php _e('Copy', 'quizify-pro'); ?></button>
        </div>
        
        <p class="description"><?php _e('Add this shortcode to any post or page where you want to display the quiz.', 'quizify-pro'); ?></p>
        
        <div class="quizify-shortcode-params">
            <h4><?php _e('Optional Parameters:', 'quizify-pro'); ?></h4>
            <ul>
                <li><code>title="true|false"</code> - <?php _e('Show/hide quiz title', 'quizify-pro'); ?></li>
                <li><code>description="true|false"</code> - <?php _e('Show/hide quiz description', 'quizify-pro'); ?></li>
            </ul>
            <p class="description"><?php _e('Example with parameters:', 'quizify-pro'); ?> <code>[quizify id="<?php echo $post->ID; ?>" title="false" description="true"]</code></p>
        </div>
        <?php
    }

    /**
     * Save quiz meta data.
     *
     * @since    1.0.0
     * @param    int       $post_id    The post ID.
     * @param    WP_Post   $post       The post object.
     */
    public function save_quiz_meta($post_id, $post) {
        // Check if our nonce is set
        if (!isset($_POST['quizify_meta_nonce'])) {
            return;
        }
        
        // Verify the nonce
        if (!wp_verify_nonce($_POST['quizify_meta_nonce'], 'quizify_save_meta')) {
            return;
        }
        
        // Check if this is an autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Check the user's permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Update quiz settings
        if (isset($_POST['quizify_time_limit'])) {
            update_post_meta($post_id, 'quizify_time_limit', absint($_POST['quizify_time_limit']));
        }
        
        if (isset($_POST['quizify_passing_score'])) {
            update_post_meta($post_id, 'quizify_passing_score', absint($_POST['quizify_passing_score']));
        }
        
        update_post_meta($post_id, 'quizify_randomize_questions', isset($_POST['quizify_randomize_questions']) ? '1' : '0');
        update_post_meta($post_id, 'quizify_randomize_answers', isset($_POST['quizify_randomize_answers']) ? '1' : '0');
        update_post_meta($post_id, 'quizify_show_results', isset($_POST['quizify_show_results']) ? '1' : '0');
        
        if (isset($_POST['quizify_pass_message'])) {
            update_post_meta($post_id, 'quizify_pass_message', sanitize_textarea_field($_POST['quizify_pass_message']));
        }
        
        if (isset($_POST['quizify_fail_message'])) {
            update_post_meta($post_id, 'quizify_fail_message', sanitize_textarea_field($_POST['quizify_fail_message']));
        }
        
        // Save difficulty setting
        if (isset($_POST['quizify_difficulty']) && in_array($_POST['quizify_difficulty'], array('beginner', 'intermediate', 'advanced', 'expert'))) {
            update_post_meta($post_id, 'quizify_difficulty', sanitize_text_field($_POST['quizify_difficulty']));
        } else {
            // Default to intermediate
            update_post_meta($post_id, 'quizify_difficulty', 'intermediate');
        }
        
        // Update questions
        if (isset($_POST['quizify_questions']) && is_array($_POST['quizify_questions'])) {
            $questions = array();
            
            foreach ($_POST['quizify_questions'] as $index => $question_data) {
                $question = array(
                    'text' => isset($question_data['text']) ? sanitize_textarea_field($question_data['text']) : '',
                    'type' => isset($question_data['type']) && in_array($question_data['type'], array('single', 'multiple')) ? $question_data['type'] : 'single',
                    'image_url' => isset($question_data['image_url']) ? esc_url_raw($question_data['image_url']) : '',
                    'options' => array()
                );
                
                // Process options
                if (isset($question_data['options']) && is_array($question_data['options'])) {
                    $processed_options = array();
                    
                    foreach ($question_data['options'] as $opt_index => $option_data) {
                        // Skip completely empty options (no text)
                        if (empty($option_data['text']) && $option_data['text'] !== '0') {
                            continue;
                        }
                        
                        $option = array(
                            'text' => sanitize_text_field($option_data['text']),
                            'correct' => false
                        );
                        
                        // Set correct status based on question type
                        if ($question['type'] === 'single') {
                            // For single choice, only one option can be correct
                            $option['correct'] = isset($question_data['correct']) && $question_data['correct'] == $opt_index;
                        } else {
                            // For multiple choice, multiple options can be correct
                            $option['correct'] = isset($option_data['correct']) && $option_data['correct'] === '1';
                        }
                        
                        // Use a new sequential index to avoid gaps
                        $processed_options[] = $option;
                    }
                    
                    // Ensure we have at least 2 options for a valid question
                    if (count($processed_options) >= 2) {
                        $question['options'] = $processed_options;
                        $questions[$index] = $question;
                    } else if (count($processed_options) === 1) {
                        // If only one option provided, add a blank one to keep it valid
                        $processed_options[] = array('text' => '', 'correct' => false);
                        $question['options'] = $processed_options;
                        $questions[$index] = $question;
                    }
                    // If no valid options, skip this question entirely
                }
            }
            
            update_post_meta($post_id, 'quizify_questions', $questions);
        }
    }

    /**
     * AJAX handler for saving a quiz.
     *
     * @since    1.0.0
     */
    public function ajax_save_quiz() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'quizify_admin_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'quizify-pro')));
        }
        
        // Check if we have quiz data
        if (!isset($_POST['quiz_id']) || !isset($_POST['quiz_data'])) {
            wp_send_json_error(array('message' => __('Missing required data.', 'quizify-pro')));
        }
        
        $quiz_id = absint($_POST['quiz_id']);
        $quiz_data = json_decode(stripslashes($_POST['quiz_data']), true);
        
        if (!is_array($quiz_data)) {
            wp_send_json_error(array('message' => __('Invalid quiz data format.', 'quizify-pro')));
        }
        
        // Check user permissions
        if (!current_user_can('edit_post', $quiz_id)) {
            wp_send_json_error(array('message' => __('You do not have permission to edit this quiz.', 'quizify-pro')));
        }
        
        // Update quiz settings
        if (isset($quiz_data['settings'])) {
            $settings = $quiz_data['settings'];
            
            if (isset($settings['time_limit'])) {
                update_post_meta($quiz_id, 'quizify_time_limit', absint($settings['time_limit']));
            }
            
            if (isset($settings['passing_score'])) {
                update_post_meta($quiz_id, 'quizify_passing_score', absint($settings['passing_score']));
            }
            
            if (isset($settings['randomize_questions'])) {
                update_post_meta($quiz_id, 'quizify_randomize_questions', $settings['randomize_questions'] ? '1' : '0');
            }
            
            if (isset($settings['randomize_answers'])) {
                update_post_meta($quiz_id, 'quizify_randomize_answers', $settings['randomize_answers'] ? '1' : '0');
            }
            
            if (isset($settings['show_results'])) {
                update_post_meta($quiz_id, 'quizify_show_results', $settings['show_results'] ? '1' : '0');
            }
            
            if (isset($settings['pass_message'])) {
                update_post_meta($quiz_id, 'quizify_pass_message', sanitize_textarea_field($settings['pass_message']));
            }
            
            if (isset($settings['fail_message'])) {
                update_post_meta($quiz_id, 'quizify_fail_message', sanitize_textarea_field($settings['fail_message']));
            }
            
            if (isset($settings['difficulty']) && in_array($settings['difficulty'], array('beginner', 'intermediate', 'advanced', 'expert'))) {
                update_post_meta($quiz_id, 'quizify_difficulty', sanitize_text_field($settings['difficulty']));
            }
        }
        
        // Update questions
        if (isset($quiz_data['questions']) && is_array($quiz_data['questions'])) {
            $questions = array();
            
            foreach ($quiz_data['questions'] as $index => $question_data) {
                $question = array(
                    'text' => isset($question_data['text']) ? sanitize_textarea_field($question_data['text']) : '',
                    'type' => isset($question_data['type']) && in_array($question_data['type'], array('single', 'multiple')) ? $question_data['type'] : 'single',
                    'image_url' => isset($question_data['image_url']) ? esc_url_raw($question_data['image_url']) : '',
                    'options' => array()
                );
                
                // Process options
                if (isset($question_data['options']) && is_array($question_data['options'])) {
                    $processed_options = array();
                    
                    foreach ($question_data['options'] as $opt_index => $option_data) {
                        // Skip completely empty options (no text)
                        if (empty($option_data['text']) && $option_data['text'] !== '0') {
                            continue;
                        }
                        
                        $option = array(
                            'text' => isset($option_data['text']) ? sanitize_text_field($option_data['text']) : '',
                            'correct' => isset($option_data['correct']) && $option_data['correct']
                        );
                        
                        // Use a new sequential index to avoid gaps
                        $processed_options[] = $option;
                    }
                    
                    // Ensure we have at least 2 options for a valid question
                    if (count($processed_options) >= 2) {
                        $question['options'] = $processed_options;
                        $questions[$index] = $question;
                    } else if (count($processed_options) === 1) {
                        // If only one option provided, add a blank one to make it valid
                        $processed_options[] = array('text' => '', 'correct' => false);
                        $question['options'] = $processed_options;
                        $questions[$index] = $question;
                    }
                    // Skip questions with no valid options
                    else if (count($processed_options) === 0) {
                        continue;
                    }
                } else {
                    // Skip questions with no options
                    continue;
                }
            }
            
            update_post_meta($quiz_id, 'quizify_questions', $questions);
        }
        
        wp_send_json_success(array('message' => __('Quiz saved successfully.', 'quizify-pro')));
    }

    /**
     * Render the settings page.
     *
     * @since    1.0.0
     */
    public function render_settings_page() {
        // Handle form submission
        if (isset($_POST['quizify_settings_nonce']) && wp_verify_nonce($_POST['quizify_settings_nonce'], 'quizify_save_settings')) {
            $settings = array(
                'default_passing_score' => isset($_POST['default_passing_score']) ? absint($_POST['default_passing_score']) : 70,
                'show_detailed_results' => isset($_POST['show_detailed_results']) ? '1' : '0',
                'enable_analytics' => isset($_POST['enable_analytics']) ? '1' : '0'
            );
            
            update_option('quizify_settings', $settings);
            $message = __('Settings saved successfully.', 'quizify-pro');
        }
        
        // Get current settings
        $settings = get_option('quizify_settings', array(
            'default_passing_score' => 70,
            'show_detailed_results' => '1',
            'enable_analytics' => '1'
        ));
        
        // Output HTML
        ?>
        <div class="wrap">
            <h1><?php _e('Quizify Settings', 'quizify-pro'); ?></h1>
            
            <?php if (isset($message)): ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php echo esc_html($message); ?></p>
                </div>
            <?php endif; ?>
            
            <form method="post" action="">
                <?php wp_nonce_field('quizify_save_settings', 'quizify_settings_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Default Passing Score (%)', 'quizify-pro'); ?></th>
                        <td>
                            <input type="number" name="default_passing_score" value="<?php echo esc_attr($settings['default_passing_score']); ?>" min="0" max="100" step="1">
                            <p class="description"><?php _e('Default passing score percentage for new quizzes.', 'quizify-pro'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Show Detailed Results', 'quizify-pro'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="show_detailed_results" value="1" <?php checked($settings['show_detailed_results'], '1'); ?>>
                                <?php _e('Show detailed results to users after quiz completion', 'quizify-pro'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Enable Analytics', 'quizify-pro'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="enable_analytics" value="1" <?php checked($settings['enable_analytics'], '1'); ?>>
                                <?php _e('Enable tracking of quiz attempts and analytics', 'quizify-pro'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e('Save Settings', 'quizify-pro'); ?>">
                </p>
            </form>
        </div>
        <?php
    }

    /**
     * Render the license page.
     *
     * @since    1.0.0
     */
    public function render_license_page() {
        // Handle form submission
        if (isset($_POST['quizify_license_nonce']) && wp_verify_nonce($_POST['quizify_license_nonce'], 'quizify_save_license')) {
            $license_key = isset($_POST['license_key']) ? sanitize_text_field($_POST['license_key']) : '';
            
            $license = new Quizify_License();
            $result = $license->activate_license($license_key);
            
            if ($result['success']) {
                $message_type = 'success';
            } else {
                $message_type = 'error';
            }
            
            $message = $result['message'];
        }
        
        // Get current license status
        $license_key = get_option('quizify_license_key', '');
        $license_status = get_option('quizify_license_status', '');
        
        // Output HTML
        ?>
        <div class="wrap">
            <h1><?php _e('Quizify License', 'quizify-pro'); ?></h1>
            
            <?php if (isset($message)): ?>
                <div class="notice notice-<?php echo esc_attr($message_type); ?> is-dismissible">
                    <p><?php echo esc_html($message); ?></p>
                </div>
            <?php endif; ?>
            
            <form method="post" action="">
                <?php wp_nonce_field('quizify_save_license', 'quizify_license_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('License Key', 'quizify-pro'); ?></th>
                        <td>
                            <input type="text" name="license_key" value="<?php echo esc_attr($license_key); ?>" class="regular-text">
                            <p class="description"><?php _e('Enter your license key to activate the premium features.', 'quizify-pro'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('License Status', 'quizify-pro'); ?></th>
                        <td>
                            <?php if ($license_status === 'valid'): ?>
                                <span style="color:green;font-weight:bold;">✓ <?php _e('Active', 'quizify-pro'); ?></span>
                            <?php elseif ($license_status === 'invalid'): ?>
                                <span style="color:red;font-weight:bold;">✗ <?php _e('Invalid', 'quizify-pro'); ?></span>
                            <?php else: ?>
                                <span style="color:orange;font-weight:bold;">! <?php _e('Inactive', 'quizify-pro'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e('Activate License', 'quizify-pro'); ?>">
                </p>
            </form>
        </div>
        <?php
    }
}