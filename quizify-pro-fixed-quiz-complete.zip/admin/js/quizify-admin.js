/**
 * Quizify Admin JavaScript
 * 
 * Handles quiz editing and management in the admin area
 */
(function($) {
    'use strict';
    
    // Initialize when DOM is ready
    $(document).ready(function() {
        // Quiz editor functionality
        initQuizEditor();
        
        // Copy shortcode functionality
        initShortcodeCopy();
    });
    
    /**
     * Initialize quiz editor
     */
    function initQuizEditor() {
        const $questionsContainer = $('.quizify-questions');
        console.log('Initializing quiz editor');
        
        // Make questions sortable
        if ($questionsContainer.length) {
            $questionsContainer.sortable({
                handle: '.quizify-question-handle',
                placeholder: 'quizify-question-placeholder',
                update: function() {
                    reindexQuestions();
                }
            });
        } else {
            console.error('Questions container not found');
        }
        
        // Toggle question editing
        $(document).on('click', '.quizify-toggle-question', function() {
            const $question = $(this).closest('.quizify-question');
            $question.find('.quizify-question-content').slideToggle(200);
            $(this).text($(this).text() === 'Edit' ? 'Close' : 'Edit');
        });
        
        // Add new question
        $(document).on('click', '.quizify-add-question-button', function(e) {
            e.preventDefault();
            console.log('Add Question button clicked');
            
            const $template = $('.quizify-question-template');
            if (!$template.length) {
                console.error('Question template not found');
                return;
            }
            
            const $newQuestion = $template.html();
            const index = $('.quizify-question').length;
            const $questionWithIndex = $newQuestion.replace(/{{index}}/g, index);
            
            $questionsContainer.append($questionWithIndex);
            reindexQuestions();
            
            // Show the new question content
            $('.quizify-question').last().find('.quizify-question-content').show();
            
            // Make options sortable
            initOptionsSortable($('.quizify-question').last().find('.quizify-options-list'));
        });
        
        // Remove question
        $(document).on('click', '.quizify-remove-question-button', function(e) {
            e.preventDefault();
            console.log('Remove Question button clicked');
            if (confirm('Are you sure you want to remove this question?')) {
                $(this).closest('.quizify-question').remove();
                reindexQuestions();
            }
        });
        
        // Add new option
        $(document).on('click', '.quizify-add-option-button', function(e) {
            e.preventDefault();
            console.log('Add Option button clicked');
            
            const $optionsList = $(this).closest('.quizify-field').find('.quizify-options-list');
            const questionElement = $(this).closest('.quizify-question');
            const questionIndex = questionElement.data('index');
            const optionIndex = $optionsList.children().length;
            const questionType = questionElement.find('.quizify-question-type').val();
            
            console.log('Adding option:', {
                questionIndex: questionIndex,
                optionIndex: optionIndex,
                questionType: questionType,
                templateExists: $('.quizify-option-template').length > 0
            });
            
            const $template = $('.quizify-option-template');
            if ($template.length === 0) {
                console.error('Option template not found, creating option directly');
                
                // Create HTML directly since template is missing
                let optionHtml = `
                    <div class="quizify-option-item">
                        <div class="quizify-option-handle">
                            <span class="dashicons dashicons-menu"></span>
                        </div>
                        <div class="quizify-option-content">
                            <input type="text" name="quizify_questions[${questionIndex}][options][${optionIndex}][text]" value="" placeholder="Option text">
                        </div>
                        <div class="quizify-option-correct">
                `;
                
                if (questionType === 'single') {
                    optionHtml += `
                            <label>
                                <input type="radio" name="quizify_questions[${questionIndex}][correct]" value="${optionIndex}">
                                ${quizify_admin.strings ? quizify_admin.strings.correct : 'Correct'}
                            </label>
                    `;
                } else {
                    optionHtml += `
                            <label>
                                <input type="checkbox" name="quizify_questions[${questionIndex}][options][${optionIndex}][correct]" value="1">
                                ${quizify_admin.strings ? quizify_admin.strings.correct : 'Correct'}
                            </label>
                    `;
                }
                
                optionHtml += `
                        </div>
                        <div class="quizify-option-actions">
                            <button type="button" class="button quizify-remove-option-button">Remove</button>
                        </div>
                    </div>
                `;
                
                $optionsList.append(optionHtml);
            } else {
                let $newOption = $template.html();
                $newOption = $newOption
                    .replace(/{{questionIndex}}/g, questionIndex)
                    .replace(/{{optionIndex}}/g, optionIndex);
                
                $optionsList.append($newOption);
                
                // Show/hide the appropriate input type based on question type
                const $addedOption = $optionsList.children().last();
                if (questionType === 'single') {
                    $addedOption.find('.quizify-correct-radio').closest('label').show();
                    $addedOption.find('.quizify-correct-checkbox-label').hide();
                } else {
                    $addedOption.find('.quizify-correct-radio').closest('label').hide();
                    $addedOption.find('.quizify-correct-checkbox-label').show();
                }
            }
            
            console.log('Option added successfully. Total options:', $optionsList.children().length);
        });
        
        // Remove option
        $(document).on('click', '.quizify-remove-option-button', function(e) {
            e.preventDefault();
            console.log('Remove Option button clicked');
            const $optionsList = $(this).closest('.quizify-options-list');
            
            // Prevent removing if only 2 options remain
            if ($optionsList.children().length <= 2) {
                alert('A question must have at least two options.');
                return;
            }
            
            $(this).closest('.quizify-option-item').remove();
            
            // Reindex options
            reindexOptions($optionsList);
        });
        
        // Update title when question text changes
        $(document).on('input', '[name^="quizify_questions"][name$="[text]"]', function() {
            const $title = $(this).closest('.quizify-question').find('.quizify-question-title');
            $title.text($(this).val() || 'New Question');
        });
        
        // Handle question type change
        $(document).on('change', '.quizify-question-type', function() {
            const $question = $(this).closest('.quizify-question');
            const questionType = $(this).val();
            
            // Update correct answer behavior
            updateCorrectAnswerBehavior($question);
        });
        
        // Make existing options sortable
        $('.quizify-options-list').each(function() {
            initOptionsSortable($(this));
        });
        
        // Handle correct option selection for single-choice questions
        $(document).on('change', 'input[name$="[correct]"]', function() {
            const $question = $(this).closest('.quizify-question');
            const questionType = $question.find('.quizify-question-type').val();
            
            // For single-choice questions, ensure only one option is checked
            if (questionType === 'single') {
                const $currentOption = $(this).closest('.quizify-option-item');
                $question.find('.quizify-option-item').not($currentOption).find('input[name$="[correct]"]').prop('checked', false);
            }
        });
    }
    
    /**
     * Make options sortable
     */
    function initOptionsSortable($container) {
        $container.sortable({
            handle: '.quizify-option-handle',
            placeholder: 'quizify-option-placeholder',
            update: function() {
                reindexOptions($(this));
            }
        });
    }
    
    /**
     * Reindex questions after sorting or removing
     */
    function reindexQuestions() {
        console.log('Reindexing questions');
        $('.quizify-question').each(function(index) {
            const $question = $(this);
            $question.attr('data-index', index);
            
            // Update question number in the title (e.g., "Question 1")
            $question.find('.quizify-question-header h3').text('Question ' + (index + 1));
            
            // Update question text input name
            $question.find('input[id^="quizify_question_text_"]').attr('id', 'quizify_question_text_' + index);
            $question.find('input[name^="quizify_questions"][name$="[text]"]').attr('name', 'quizify_questions[' + index + '][text]');
            
            // Update question type input name
            $question.find('select[id^="quizify_question_type_"]').attr('id', 'quizify_question_type_' + index);
            $question.find('select[name^="quizify_questions"][name$="[type]"]').attr('name', 'quizify_questions[' + index + '][type]');
            
            // Reindex options within this question
            reindexOptions($question.find('.quizify-options-list'));
        });
    }
    
    /**
     * Reindex options after sorting or removing
     */
    function reindexOptions($container) {
        console.log('Reindexing options');
        $container.children().each(function(index) {
            const $option = $(this);
            const $question = $option.closest('.quizify-question');
            const questionIndex = $question.data('index');
            
            console.log('Reindexing option:', index, 'for question:', questionIndex);
            
            // Update option text input name
            $option.find('input[type="text"]').attr('name', 'quizify_questions[' + questionIndex + '][options][' + index + '][text]');
            
            // Update option correct checkbox name
            $option.find('input[type="checkbox"]').attr('name', 'quizify_questions[' + questionIndex + '][options][' + index + '][correct]');
            
            // Update radio button value and ID for single-choice questions
            const $radio = $option.find('input[type="radio"]');
            if ($radio.length) {
                $radio.val(index).attr('id', 'quizify_question_' + questionIndex + '_option_' + index);
                $radio.next('label').attr('for', 'quizify_question_' + questionIndex + '_option_' + index);
            }
            
            // Also update any data-option attributes
            $option.find('[data-option]').attr('data-option', index);
        });
        
        console.log('Reindexing complete. Total options:', $container.children().length);
    }
    
    /**
     * Update correct answer behavior based on question type
     */
    function updateCorrectAnswerBehavior($question) {
        const questionType = $question.find('.quizify-question-type').val();
        const questionIndex = $question.data('index');
        
        if (questionType === 'single') {
            // Switch to radio buttons for single-choice questions
            $question.find('.quizify-option-item').each(function(optionIndex) {
                const $optionItem = $(this);
                const $correctContainer = $optionItem.find('.quizify-option-correct');
                
                // Check if we need to replace a checkbox with a radio button
                if ($correctContainer.find('input[type="checkbox"]').length) {
                    const isChecked = $correctContainer.find('input[type="checkbox"]').prop('checked');
                    
                    // Create radio button HTML
                    const radioHtml = `
                        <label>
                            <input type="radio" name="quizify_questions[${questionIndex}][correct]" value="${optionIndex}" ${isChecked ? 'checked' : ''}>
                            ${quizify_admin.strings.correct}
                        </label>
                    `;
                    
                    // Replace the content
                    $correctContainer.html(radioHtml);
                }
            });
            
            // Ensure only one radio button is checked
            const $checkedOptions = $question.find('input[type="radio"][name$="[correct]"]:checked');
            if ($checkedOptions.length > 1) {
                $checkedOptions.not(':first').prop('checked', false);
            }
        } else if (questionType === 'multiple') {
            // Switch to checkboxes for multiple-choice questions
            $question.find('.quizify-option-item').each(function(optionIndex) {
                const $optionItem = $(this);
                const $correctContainer = $optionItem.find('.quizify-option-correct');
                
                // Check if we need to replace a radio button with a checkbox
                if ($correctContainer.find('input[type="radio"]').length) {
                    const isChecked = $correctContainer.find('input[type="radio"]').prop('checked');
                    
                    // Create checkbox HTML
                    const checkboxHtml = `
                        <label>
                            <input type="checkbox" name="quizify_questions[${questionIndex}][options][${optionIndex}][correct]" value="1" ${isChecked ? 'checked' : ''}>
                            ${quizify_admin.strings.correct}
                        </label>
                    `;
                    
                    // Replace the content
                    $correctContainer.html(checkboxHtml);
                }
            });
        }
    }
    
    /**
     * Initialize shortcode copy functionality
     */
    function initShortcodeCopy() {
        $('.quizify-copy-shortcode').on('click', function() {
            const $shortcode = $(this).closest('.quizify-shortcode-wrap').find('.quizify-shortcode');
            const temp = $('<input>');
            $('body').append(temp);
            temp.val($shortcode.text()).select();
            document.execCommand('copy');
            temp.remove();
            
            // Show feedback
            const $button = $(this);
            const originalText = $button.text();
            $button.text('Copied!');
            setTimeout(function() {
                $button.text(originalText);
            }, 1500);
        });
    }
})(jQuery);
