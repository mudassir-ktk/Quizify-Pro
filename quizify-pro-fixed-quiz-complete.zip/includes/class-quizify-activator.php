<?php
/**
 * Fired during plugin activation
 *
 * @since      1.0.0
 *
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/includes
 */

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/includes
 * @author     NetworkUstad Team
 */
class Quizify_Activator {

    /**
     * Initialize database tables, set up initial settings,
     * and other activation tasks.
     *
     * @since    1.0.0
     */
    public static function activate() {
        global $wpdb;
        
        // Initialize analytics tables
        self::create_tables();
        
        // Set default plugin settings
        self::set_default_settings();
        
        // Register post type to flush rewrite rules
        self::register_post_type();
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Create database tables.
     *
     * @since    1.0.0
     */
    private static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        $attempts_table = $wpdb->prefix . 'quizify_attempts';
        $detailed_table = $wpdb->prefix . 'quizify_attempt_details';
        
        // Make sure we have the dbDelta function
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        // Create attempts table
        $sql = "CREATE TABLE $attempts_table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            quiz_id bigint(20) unsigned NOT NULL,
            user_id bigint(20) unsigned DEFAULT NULL,
            user_ip varchar(100) DEFAULT NULL,
            score int(11) DEFAULT 0,
            passed tinyint(1) DEFAULT 0,
            time_spent int(11) DEFAULT 0,
            location varchar(255) DEFAULT NULL,
            traffic_source varchar(255) DEFAULT NULL,
            referrer varchar(255) DEFAULT NULL,
            keywords varchar(255) DEFAULT NULL,
            search_query varchar(255) DEFAULT NULL,
            date_created datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY quiz_id (quiz_id),
            KEY user_id (user_id)
        ) $charset_collate;";
        
        dbDelta($sql);
        
        // Create attempt details table
        $sql = "CREATE TABLE $detailed_table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            attempt_id bigint(20) unsigned NOT NULL,
            question_id varchar(100) NOT NULL,
            answer text DEFAULT NULL,
            is_correct tinyint(1) DEFAULT 0,
            time_spent int(11) DEFAULT 0,
            PRIMARY KEY  (id),
            KEY attempt_id (attempt_id)
        ) $charset_collate;";
        
        dbDelta($sql);
        
        // Create search queries table for tracking analytics searches
        $search_queries_table = $wpdb->prefix . 'quizify_search_queries';
        $sql = "CREATE TABLE $search_queries_table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            quiz_id bigint(20) unsigned NOT NULL DEFAULT 0,
            search_term varchar(255) NOT NULL,
            result_count int(11) NOT NULL DEFAULT 0,
            date_created datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY quiz_id (quiz_id),
            KEY search_term (search_term(191)),
            KEY date_created (date_created)
        ) $charset_collate;";
        
        dbDelta($sql);
    }
    
    /**
     * Set default settings.
     *
     * @since    1.0.0
     */
    private static function set_default_settings() {
        $settings = get_option('quizify_settings', false);
        
        if (!$settings) {
            $default_settings = array(
                'default_passing_score' => 70,
                'show_detailed_results' => '1',
                'enable_analytics' => '1'
            );
            
            update_option('quizify_settings', $default_settings);
        }
    }
    
    /**
     * Register post type.
     *
     * @since    1.0.0
     */
    private static function register_post_type() {
        $labels = array(
            'name'                  => _x('Quizzes', 'Post type general name', 'quizify-pro'),
            'singular_name'         => _x('Quiz', 'Post type singular name', 'quizify-pro'),
            'menu_name'             => _x('Quizify', 'Admin Menu text', 'quizify-pro'),
            'name_admin_bar'        => _x('Quiz', 'Add New on Toolbar', 'quizify-pro'),
            'add_new'               => __('Add New', 'quizify-pro'),
            'add_new_item'          => __('Add New Quiz', 'quizify-pro'),
            'new_item'              => __('New Quiz', 'quizify-pro'),
            'edit_item'             => __('Edit Quiz', 'quizify-pro'),
            'view_item'             => __('View Quiz', 'quizify-pro'),
            'all_items'             => __('All Quizzes', 'quizify-pro'),
            'search_items'          => __('Search Quizzes', 'quizify-pro'),
            'parent_item_colon'     => __('Parent Quizzes:', 'quizify-pro'),
            'not_found'             => __('No quizzes found.', 'quizify-pro'),
            'not_found_in_trash'    => __('No quizzes found in Trash.', 'quizify-pro')
        );
        
        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array('slug' => 'quiz'),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'menu_icon'          => 'dashicons-clipboard',
            'supports'           => array('title', 'editor', 'thumbnail')
        );
        
        register_post_type('quizify_quiz', $args);
    }
}