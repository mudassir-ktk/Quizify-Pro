<?php
/**
 * Quiz functionality for Quizify Pro
 *
 * @since      1.0.0
 *
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/includes
 */

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * Quiz class.
 *
 * Handles quiz data retrieval and processing.
 *
 * @since      1.0.0
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/includes
 * @author     NetworkUstad Team
 */
class Quizify_Quiz {

    /**
     * Get quiz data for display.
     *
     * @since    1.0.0
     * @param    int     $quiz_id    The ID of the quiz to retrieve.
     * @return   array                The quiz data.
     */
    public static function get_quiz_data($quiz_id) {
        // Get quiz post
        $quiz = get_post($quiz_id);
        
        if (!$quiz || $quiz->post_type !== 'quizify_quiz') {
            return false;
        }
        
        // Get quiz meta
        $time_limit = get_post_meta($quiz_id, 'quizify_time_limit', true);
        $passing_score = get_post_meta($quiz_id, 'quizify_passing_score', true);
        $randomize_questions = get_post_meta($quiz_id, 'quizify_randomize_questions', true);
        $randomize_answers = get_post_meta($quiz_id, 'quizify_randomize_answers', true);
        $questions = get_post_meta($quiz_id, 'quizify_questions', true);
        
        // Set defaults
        if (!$passing_score) {
            $settings = get_option('quizify_settings', array());
            $passing_score = isset($settings['default_passing_score']) ? $settings['default_passing_score'] : 70;
        }
        
        // Prepare data
        $data = array(
            'id' => $quiz_id,
            'title' => $quiz->post_title,
            'description' => $quiz->post_content,
            'time_limit' => $time_limit ? absint($time_limit) : 0,
            'passing_score' => $passing_score ? absint($passing_score) : 70,
            'randomize_questions' => $randomize_questions === '1',
            'randomize_answers' => $randomize_answers === '1',
            'questions' => array()
        );
        
        // Process questions
        if (is_array($questions) && !empty($questions)) {
            foreach ($questions as $index => $question) {
                $question_data = array(
                    'id' => $index,
                    'text' => isset($question['text']) ? $question['text'] : '',
                    'description' => isset($question['description']) ? $question['description'] : '',
                    'type' => isset($question['type']) ? $question['type'] : 'single',
                    'options' => array()
                );
                
                // Add image if it exists
                if (isset($question['image_url']) && !empty($question['image_url'])) {
                    $question_data['image_url'] = $question['image_url'];
                }
                
                // Process options based on question type
                if (isset($question['options']) && is_array($question['options'])) {
                    // Create a temporary array to store options with their original indices
                    $temp_options = array();
                    
                    if ($question_data['type'] === 'true_false') {
                        // For true/false questions, ensure we only have two options (True and False)
                        $temp_options[] = array(
                            'id' => 'true',
                            'text' => __('True', 'quizify-pro'),
                            'correct' => isset($question['correct']) && $question['correct'] === 'true',
                        );
                        $temp_options[] = array(
                            'id' => 'false',
                            'text' => __('False', 'quizify-pro'),
                            'correct' => isset($question['correct']) && $question['correct'] === 'false',
                        );
                    } elseif ($question_data['type'] === 'text' || $question_data['type'] === 'paragraph') {
                        // For text or paragraph type, we store the correct answer
                        $temp_options[] = array(
                            'id' => 'answer',
                            'text' => isset($question['correct_answer']) ? $question['correct_answer'] : '',
                            'correct' => true,
                        );
                    } else {
                        // For multiple choice or single choice
                        foreach ($question['options'] as $opt_index => $option) {
                            $temp_options[] = array(
                                'id' => $opt_index,
                                'text' => isset($option['text']) ? $option['text'] : '',
                                'correct' => isset($option['correct']) ? $option['correct'] : false,
                            );
                        }
                    }
                    
                    // Randomize options if setting is enabled (only for multiple/single choice)
                    if ($randomize_answers === '1' && 
                        ($question_data['type'] === 'multiple' || $question_data['type'] === 'single')) {
                        shuffle($temp_options);
                    }
                    
                    // Add options to question data (exclude correct answers for public facing data)
                    foreach ($temp_options as $option) {
                        $option_data = array(
                            'id' => $option['id'],
                            'text' => $option['text'],
                        );
                        
                        // For text/paragraph types, we don't need to expose the correct answer
                        if ($question_data['type'] !== 'text' && $question_data['type'] !== 'paragraph') {
                            $question_data['options'][] = $option_data;
                        }
                    }
                }
                
                $data['questions'][] = $question_data;
            }
            
            // Randomize questions if setting is enabled
            if ($randomize_questions === '1') {
                shuffle($data['questions']);
            }
        }
        
        return $data;
    }
    
    /**
     * Score a quiz submission.
     *
     * @since    1.0.0
     * @param    int      $quiz_id    The ID of the quiz.
     * @param    array    $answers    The answers submitted.
     * @return   array                The scoring results.
     */
    public static function score_quiz($quiz_id, $answers) {
        try {
            // Validate quiz ID
            if (empty($quiz_id)) {
                error_log("Quizify: quiz_id is empty");
                return false;
            }
            
            // Validate answers format
            if (!is_array($answers)) {
                error_log("Quizify: answers is not an array: " . gettype($answers));
                return false;
            }
            
            // Get quiz post
            $quiz = get_post($quiz_id);
            
            if (!$quiz || $quiz->post_type !== 'quizify_quiz') {
                error_log("Quizify: Invalid quiz with ID $quiz_id");
                return false;
            }
            
            // Get quiz meta
            $passing_score = get_post_meta($quiz_id, 'quizify_passing_score', true);
            $questions = get_post_meta($quiz_id, 'quizify_questions', true);
            
            // Validate questions format
            if (!is_array($questions)) {
                error_log("Quizify: No valid questions found for quiz ID $quiz_id");
                return false;
            }
            
            // Set default passing score if not set
            if (!$passing_score) {
                $settings = get_option('quizify_settings', array());
                $passing_score = isset($settings['default_passing_score']) ? $settings['default_passing_score'] : 70;
            }
        
        // Initialize results
        $results = array(
            'quiz_id' => $quiz_id,
            'title' => $quiz->post_title,
            'passing_score' => $passing_score ? absint($passing_score) : 70,
            'questions' => array(),
            'total_questions' => 0,
            'correct_answers' => 0,
            'score' => 0,
            'passed' => false,
        );
        
        // Process questions and score answers
        if (is_array($questions) && !empty($questions)) {
            $results['total_questions'] = count($questions);
            
            foreach ($questions as $index => $question) {
                $question_type = isset($question['type']) ? $question['type'] : 'single';
                $user_answer = isset($answers[$index]) ? $answers[$index] : null;
                $is_correct = false;
                $correct_answers = array();
                
                // Process based on question type
                switch ($question_type) {
                    case 'single':
                        // Single choice - get the correct option
                        if (isset($question['options']) && is_array($question['options'])) {
                            foreach ($question['options'] as $opt_index => $option) {
                                if (isset($option['correct']) && $option['correct']) {
                                    $correct_answers[] = $opt_index;
                                }
                            }
                        }
                        // Check if the selected option is correct
                        $is_correct = !empty($user_answer) && is_array($user_answer) && 
                                    count($user_answer) > 0 && in_array($user_answer[0], $correct_answers);
                        break;
                        
                    case 'multiple':
                        // Multiple choice - check if all correct options are selected and no incorrect ones
                        if (isset($question['options']) && is_array($question['options'])) {
                            foreach ($question['options'] as $opt_index => $option) {
                                if (isset($option['correct']) && $option['correct']) {
                                    $correct_answers[] = $opt_index;
                                }
                            }
                        }
                        
                        // Both arrays must have the same elements (order doesn't matter)
                        if (is_array($user_answer) && !empty($user_answer)) {
                            // Sort both arrays to make comparison easier
                            sort($correct_answers);
                            sort($user_answer);
                            
                            // Check if all selected options are correct and all correct options are selected
                            $is_correct = true;
                            
                            // Check that all selected answers are correct
                            foreach ($user_answer as $answer) {
                                if (!in_array($answer, $correct_answers)) {
                                    $is_correct = false;
                                    break;
                                }
                            }
                            
                            // Check that all correct answers are selected
                            if ($is_correct) {
                                foreach ($correct_answers as $correct) {
                                    if (!in_array($correct, $user_answer)) {
                                        $is_correct = false;
                                        break;
                                    }
                                }
                            }
                        } else {
                            $is_correct = (empty($correct_answers)); // Only correct if there are no correct answers
                        }
                        break;
                        
                    case 'true_false':
                        // True/False - check if the answer matches the correct value
                        $correct_answer = isset($question['correct']) ? $question['correct'] : null;
                        $is_correct = (string)$user_answer === (string)$correct_answer;
                        $correct_answers = array($correct_answer);
                        break;
                        
                    case 'text':
                        // Text input - check if answer matches exactly (case insensitive)
                        $correct_answer = isset($question['correct_answer']) ? $question['correct_answer'] : '';
                        $is_correct = !empty($user_answer) && 
                                    (strtolower(trim((string)$user_answer)) === strtolower(trim($correct_answer)));
                        $correct_answers = array($correct_answer);
                        break;
                        
                    case 'paragraph':
                        // Paragraph input - check if answer contains the correct keywords
                        $correct_answer = isset($question['correct_answer']) ? $question['correct_answer'] : '';
                        $keywords = isset($question['keywords']) ? $question['keywords'] : array();
                        
                        if (!empty($user_answer)) {
                            if (!empty($keywords) && is_array($keywords)) {
                                // If keywords are specified, check for their presence
                                $matched_keywords = 0;
                                foreach ($keywords as $keyword) {
                                    if (stripos($user_answer, $keyword) !== false) {
                                        $matched_keywords++;
                                    }
                                }
                                // Consider correct if at least 70% of keywords are found
                                $is_correct = (!empty($keywords)) ? 
                                            ($matched_keywords / count($keywords)) >= 0.7 : false;
                            } else {
                                // If no keywords, check if answer contains main parts of the correct answer
                                $is_correct = !empty($correct_answer) && 
                                            (stripos($user_answer, $correct_answer) !== false || 
                                            similar_text($user_answer, $correct_answer) / strlen($correct_answer) > 0.7);
                            }
                        } else {
                            $is_correct = false;
                        }
                        $correct_answers = array($correct_answer);
                        break;
                }
                
                // Add to correct answer count
                if ($is_correct) {
                    $results['correct_answers']++;
                }
                
                // Add question result to detailed results
                $results['questions'][] = array(
                    'id' => $index,
                    'text' => isset($question['text']) ? $question['text'] : '',
                    'type' => $question_type,
                    'user_answer' => $user_answer,
                    'correct_answer' => $correct_answers,
                    'correct' => $is_correct,
                );
            }
            
            // Calculate score as percentage
            if ($results['total_questions'] > 0) {
                $results['score'] = round(($results['correct_answers'] / $results['total_questions']) * 100);
            }
            
            // Determine if passed
            $results['passed'] = $results['score'] >= $results['passing_score'];
            
            // Add custom pass/fail messages if set
            $pass_message = get_post_meta($quiz_id, 'quizify_pass_message', true);
            $fail_message = get_post_meta($quiz_id, 'quizify_fail_message', true);
            
            $results['pass_message'] = !empty($pass_message) ? $pass_message : __('Congratulations! You have passed the quiz.', 'quizify-pro');
            $results['fail_message'] = !empty($fail_message) ? $fail_message : __('Sorry, you did not pass the quiz. Try again.', 'quizify-pro');
        }
        
        return $results;
        
        } catch (Exception $e) {
            // Log any unexpected errors
            error_log("Quizify Error in score_quiz: " . $e->getMessage());
            return false;
        }
    }
}
