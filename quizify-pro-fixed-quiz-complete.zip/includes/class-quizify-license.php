<?php
/**
 * License handling for Quizify Pro
 *
 * @since      1.0.0
 *
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/includes
 */

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * License class.
 *
 * Handles license validation and activation.
 *
 * @since      1.0.0
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/includes
 * @author     NetworkUstad Team
 */
class Quizify_License {

    /**
     * Valid license keys for testing
     * 
     * @since 1.0.0
     * @access private
     * @var array Valid license keys for testing
     */
    private $valid_keys = array(
        'QZFY-PRO-PERSONAL-4852-9731-2025'
    );

    /**
     * Initialize the class.
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Nothing to do here
    }

    /**
     * Check license status.
     *
     * @since    1.0.0
     */
    public function check_license() {
        $license_key = get_option('quizify_license_key', '');
        $license_status = get_option('quizify_license_status', '');
        
        // If no license key, set status to inactive
        if (empty($license_key)) {
            update_option('quizify_license_status', '');
            return;
        }
        
        // Check if the license key is in our valid keys array
        $is_valid = in_array($license_key, $this->valid_keys);
        
        // Update status if needed
        if ($is_valid && $license_status !== 'valid') {
            update_option('quizify_license_status', 'valid');
        } elseif (!$is_valid && $license_status !== 'invalid') {
            update_option('quizify_license_status', 'invalid');
        }
    }

    /**
     * Activate license.
     *
     * @since    1.0.0
     * @param    string    $license_key    The license key to activate.
     * @return   array                    The activation result.
     */
    public function activate_license($license_key) {
        // Sanitize license key
        $license_key = sanitize_text_field($license_key);
        
        if (empty($license_key)) {
            return array(
                'success' => false,
                'message' => __('Please enter a license key.', 'quizify-pro')
            );
        }
        
        // Check if the license key is in our valid keys array
        $is_valid = in_array($license_key, $this->valid_keys);
        
        // Update license key and status
        update_option('quizify_license_key', $license_key);
        
        if ($is_valid) {
            update_option('quizify_license_status', 'valid');
            return array(
                'success' => true,
                'message' => __('License activated successfully.', 'quizify-pro')
            );
        } else {
            update_option('quizify_license_status', 'invalid');
            return array(
                'success' => false,
                'message' => __('Invalid license key.', 'quizify-pro')
            );
        }
    }

    /**
     * Deactivate license.
     *
     * @since    1.0.0
     * @return   array    The deactivation result.
     */
    public function deactivate_license() {
        // Update license status to inactive
        update_option('quizify_license_status', '');
        
        return array(
            'success' => true,
            'message' => __('License deactivated successfully.', 'quizify-pro')
        );
    }
}