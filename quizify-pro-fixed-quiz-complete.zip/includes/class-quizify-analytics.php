<?php
/**
 * Analytics functionality for Quizify Pro
 *
 * @since      1.0.0
 *
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/includes
 */

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * Analytics class.
 *
 * Handles quiz analytics data storage and retrieval.
 *
 * @since      1.0.0
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/includes
 * @author     NetworkUstad Team
 */
class Quizify_Analytics {

    /**
     * Initialize the class
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Initialize tables if needed
        add_action('init', array($this, 'maybe_create_tables'));
        
        // Register AJAX handlers for search
        add_action('wp_ajax_quizify_search_analytics', array($this, 'ajax_search_analytics'));
    }

    /**
     * Create database tables if they don't exist
     *
     * @since    1.0.0
     */
    public function maybe_create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        $attempts_table = $wpdb->prefix . 'quizify_attempts';
        $detailed_table = $wpdb->prefix . 'quizify_attempt_details';
        $search_queries_table = $wpdb->prefix . 'quizify_search_queries';

        if($wpdb->get_var("SHOW TABLES LIKE '$attempts_table'") != $attempts_table) {
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            
            // Create main attempts table
            $sql = "CREATE TABLE $attempts_table (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                quiz_id bigint(20) unsigned NOT NULL,
                user_id bigint(20) unsigned DEFAULT NULL,
                user_ip varchar(100) DEFAULT NULL,
                score int(11) DEFAULT 0,
                passed tinyint(1) DEFAULT 0,
                time_spent int(11) DEFAULT 0,
                location varchar(255) DEFAULT NULL,
                traffic_source varchar(255) DEFAULT NULL,
                referrer varchar(255) DEFAULT NULL,
                keywords varchar(255) DEFAULT NULL,
                search_query varchar(255) DEFAULT NULL,
                date_created datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY quiz_id (quiz_id),
                KEY user_id (user_id)
            ) $charset_collate;";
            
            dbDelta($sql);
            
            // Create attempt details table
            $sql = "CREATE TABLE $detailed_table (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                attempt_id bigint(20) unsigned NOT NULL,
                question_id varchar(100) NOT NULL,
                answer text DEFAULT NULL,
                is_correct tinyint(1) DEFAULT 0,
                time_spent int(11) DEFAULT 0,
                PRIMARY KEY  (id),
                KEY attempt_id (attempt_id)
            ) $charset_collate;";
            
            dbDelta($sql);
            
            // Create search queries table
            $sql = "CREATE TABLE $search_queries_table (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                user_id bigint(20) unsigned DEFAULT NULL,
                quiz_id bigint(20) unsigned DEFAULT NULL,
                search_term varchar(255) NOT NULL,
                result_count int(11) DEFAULT 0,
                date_created datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY user_id (user_id),
                KEY quiz_id (quiz_id)
            ) $charset_collate;";
            
            dbDelta($sql);
        } else {
            // Check if search_query column exists in attempts table
            $row = $wpdb->get_results("SHOW COLUMNS FROM {$attempts_table} LIKE 'search_query'");
            if (empty($row)) {
                $wpdb->query("ALTER TABLE {$attempts_table} ADD COLUMN search_query varchar(255) DEFAULT NULL AFTER keywords");
            }
            
            // Check if search queries table exists
            if($wpdb->get_var("SHOW TABLES LIKE '$search_queries_table'") != $search_queries_table) {
                require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
                
                // Create search queries table
                $sql = "CREATE TABLE $search_queries_table (
                    id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                    user_id bigint(20) unsigned DEFAULT NULL,
                    quiz_id bigint(20) unsigned DEFAULT NULL,
                    search_term varchar(255) NOT NULL,
                    result_count int(11) DEFAULT 0,
                    date_created datetime DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY  (id),
                    KEY user_id (user_id),
                    KEY quiz_id (quiz_id)
                ) $charset_collate;";
                
                dbDelta($sql);
            }
        }
    }
    
    /**
     * Add analytics page to the admin menu.
     *
     * @since    1.0.0
     */
    public function add_analytics_page() {
        add_submenu_page(
            'edit.php?post_type=quizify_quiz',
            __('Analytics', 'quizify-pro'),
            __('Analytics', 'quizify-pro'),
            'manage_options',
            'quizify-analytics',
            array($this, 'render_analytics_page')
        );
    }
    
    /**
     * Render the analytics page.
     *
     * @since    1.0.0
     */
    public function render_analytics_page() {
        // Enqueue necessary scripts and styles
        wp_enqueue_style('quizify-analytics', QUIZIFY_PRO_PLUGIN_URL . 'admin/css/quizify-analytics.css', array(), QUIZIFY_PRO_VERSION);
        
        wp_enqueue_script(
            'chart-js',
            'https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js',
            array(),
            '3.9.1',
            true
        );
        
        wp_enqueue_script(
            'quizify-analytics',
            QUIZIFY_PRO_PLUGIN_URL . 'admin/js/quizify-analytics.js',
            array('jquery', 'chart-js'),
            QUIZIFY_PRO_VERSION,
            true
        );
        
        wp_localize_script(
            'quizify-analytics',
            'quizify_analytics',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('quizify_admin_nonce'),
                'i18n' => array(
                    'no_data' => __('No data available for the selected criteria.', 'quizify-pro'),
                    'loading' => __('Loading data...', 'quizify-pro'),
                    'error' => __('Error loading data. Please try again.', 'quizify-pro'),
                )
            )
        );
        
        // Get all quizzes for filter dropdown
        $quizzes = get_posts(array(
            'post_type' => 'quizify_quiz',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
        ));
        
        // Include the analytics dashboard template
        include QUIZIFY_PRO_PLUGIN_DIR . 'admin/partials/quizify-analytics-dashboard.php';
    }

    /**
     * AJAX handler for tracking quiz start
     *
     * @since    1.0.0
     */
    public function ajax_track_start() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'quizify_public_nonce')) {
            wp_send_json_error(array('message' => 'Invalid nonce.'));
        }
        
        // Check for quiz ID
        if (!isset($_POST['quiz_id'])) {
            wp_send_json_error(array('message' => 'No quiz ID provided.'));
        }
        
        $quiz_id = absint($_POST['quiz_id']);
        
        // Get current user ID (0 if not logged in)
        $user_id = get_current_user_id();
        
        // Get user IP
        $user_ip = $this->get_user_ip();
        
        // Insert attempt record
        global $wpdb;
        $wpdb->insert(
            $wpdb->prefix . 'quizify_attempts',
            array(
                'quiz_id' => $quiz_id,
                'user_id' => $user_id,
                'user_ip' => $user_ip,
                'date_created' => current_time('mysql')
            ),
            array('%d', '%d', '%s', '%s')
        );
        
        $attempt_id = $wpdb->insert_id;
        
        wp_send_json_success(array(
            'tracked' => true,
            'attempt_id' => $attempt_id
        ));
    }

    /**
     * AJAX handler for tracking quiz completion
     *
     * @since    1.0.0
     */
    public function ajax_track_completion() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'quizify_public_nonce')) {
            wp_send_json_error(array('message' => 'Invalid nonce.'));
        }
        
        // Check for required parameters
        if (!isset($_POST['quiz_id']) || !isset($_POST['score']) || !isset($_POST['passed'])) {
            wp_send_json_error(array('message' => 'Missing required parameters.'));
        }
        
        $quiz_id = absint($_POST['quiz_id']);
        $attempt_id = isset($_POST['attempt_id']) ? absint($_POST['attempt_id']) : 0;
        $score = absint($_POST['score']);
        $passed = (bool) $_POST['passed'];
        $time_spent = isset($_POST['time_spent']) ? absint($_POST['time_spent']) : 0;
        $location = isset($_POST['location']) ? sanitize_text_field($_POST['location']) : '';
        $traffic_source = isset($_POST['traffic_source']) ? sanitize_text_field($_POST['traffic_source']) : '';
        $referrer = isset($_POST['referrer']) ? esc_url_raw($_POST['referrer']) : '';
        $keywords = isset($_POST['keywords']) ? sanitize_text_field($_POST['keywords']) : '';
        $search_query = isset($_POST['search_query']) ? sanitize_text_field($_POST['search_query']) : '';
        
        global $wpdb;
        
        // If we have an attempt ID, update the record
        if ($attempt_id > 0) {
            $wpdb->update(
                $wpdb->prefix . 'quizify_attempts',
                array(
                    'score' => $score,
                    'passed' => $passed ? 1 : 0,
                    'time_spent' => $time_spent,
                    'location' => $location,
                    'traffic_source' => $traffic_source,
                    'referrer' => $referrer,
                    'keywords' => $keywords,
                    'search_query' => $search_query
                ),
                array('id' => $attempt_id),
                array('%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s'),
                array('%d')
            );
        } else {
            // No attempt ID, create a new record
            $user_id = get_current_user_id();
            $user_ip = $this->get_user_ip();
            
            $wpdb->insert(
                $wpdb->prefix . 'quizify_attempts',
                array(
                    'quiz_id' => $quiz_id,
                    'user_id' => $user_id,
                    'user_ip' => $user_ip,
                    'score' => $score,
                    'passed' => $passed ? 1 : 0,
                    'time_spent' => $time_spent,
                    'location' => $location,
                    'traffic_source' => $traffic_source,
                    'referrer' => $referrer,
                    'keywords' => $keywords,
                    'search_query' => $search_query,
                    'date_created' => current_time('mysql')
                ),
                array('%d', '%d', '%s', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s')
            );
            
            $attempt_id = $wpdb->insert_id;
        }
        
        wp_send_json_success(array(
            'tracked' => true,
            'attempt_id' => $attempt_id
        ));
    }

    /**
     * AJAX handler for tracking quiz exit
     *
     * @since    1.0.0
     */
    public function ajax_track_exit() {
        // This is called via navigator.sendBeacon, so we won't send a response
        // But we still check nonce and required parameters
        
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'quizify_public_nonce')) {
            return;
        }
        
        if (!isset($_POST['quiz_id']) || !isset($_POST['attempt_id'])) {
            return;
        }
        
        $attempt_id = absint($_POST['attempt_id']);
        $time_spent = isset($_POST['time_spent']) ? absint($_POST['time_spent']) : 0;
        
        global $wpdb;
        
        $wpdb->update(
            $wpdb->prefix . 'quizify_attempts',
            array(
                'time_spent' => $time_spent
            ),
            array('id' => $attempt_id),
            array('%d'),
            array('%d')
        );
    }

    /**
     * AJAX handler for getting analytics data
     *
     * @since    1.0.0
     */
    public function ajax_get_analytics_data() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'quizify_admin_nonce')) {
            wp_send_json_error(array('message' => 'Invalid nonce.'));
        }
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to access this data.'));
        }
        
        // Get parameters
        $date_range = isset($_POST['date_range']) ? sanitize_text_field($_POST['date_range']) : '30days';
        $quiz_id = isset($_POST['quiz_id']) ? absint($_POST['quiz_id']) : 0;
        $start_date = isset($_POST['start_date']) ? sanitize_text_field($_POST['start_date']) : '';
        $end_date = isset($_POST['end_date']) ? sanitize_text_field($_POST['end_date']) : '';
        
        // Get analytics data
        $data = $this->get_analytics_data($date_range, $quiz_id, $start_date, $end_date);
        
        wp_send_json_success($data);
    }

    /**
     * Get analytics data for the dashboard
     *
     * @since    1.0.0
     * @param    string    $date_range    The date range to get data for
     * @param    int       $quiz_id       The quiz ID (0 for all quizzes)
     * @param    string    $start_date    The custom start date (if date_range is 'custom')
     * @param    string    $end_date      The custom end date (if date_range is 'custom')
     * @return   array                    The analytics data
     */
    private function get_analytics_data($date_range, $quiz_id = 0, $start_date = '', $end_date = '') {
        global $wpdb;
        
        $attempts_table = $wpdb->prefix . 'quizify_attempts';
        
        // Set up date constraints
        $date_constraint = '';
        
        if ($date_range === 'custom' && $start_date && $end_date) {
            $start_date = date('Y-m-d 00:00:00', strtotime($start_date));
            $end_date = date('Y-m-d 23:59:59', strtotime($end_date));
            $date_constraint = $wpdb->prepare("AND date_created BETWEEN %s AND %s", $start_date, $end_date);
        } else {
            $current_date = current_time('mysql');
            
            switch ($date_range) {
                case '7days':
                    $date_constraint = $wpdb->prepare("AND date_created >= DATE_SUB(%s, INTERVAL 7 DAY)", $current_date);
                    break;
                case '30days':
                    $date_constraint = $wpdb->prepare("AND date_created >= DATE_SUB(%s, INTERVAL 30 DAY)", $current_date);
                    break;
                case '90days':
                    $date_constraint = $wpdb->prepare("AND date_created >= DATE_SUB(%s, INTERVAL 90 DAY)", $current_date);
                    break;
                case '1year':
                    $date_constraint = $wpdb->prepare("AND date_created >= DATE_SUB(%s, INTERVAL 1 YEAR)", $current_date);
                    break;
                case 'all':
                default:
                    $date_constraint = '';
                    break;
            }
        }
        
        // Quiz constraint
        $quiz_constraint = $quiz_id > 0 ? $wpdb->prepare("AND quiz_id = %d", $quiz_id) : '';
        
        // Get main stats
        $query = "
            SELECT 
                COUNT(*) as total_attempts,
                SUM(CASE WHEN passed = 1 THEN 1 ELSE 0 END) as total_passed,
                AVG(score) as average_score,
                AVG(time_spent) as average_time
            FROM $attempts_table
            WHERE 1=1 $quiz_constraint $date_constraint
        ";
        
        $stats = $wpdb->get_row($query);
        
        // Format stats
        $total_attempts = (int) $stats->total_attempts;
        $total_passed = (int) $stats->total_passed;
        $average_score = round(floatval($stats->average_score), 1);
        $pass_rate = $total_attempts > 0 ? round(($total_passed / $total_attempts) * 100, 1) : 0;
        
        // Prepare data object
        $data = array(
            'total_attempts' => $total_attempts,
            'total_passed' => $total_passed,
            'average_score' => $average_score,
            'pass_rate' => $pass_rate,
        );
        
        // Get daily stats for chart
        if ($date_range === 'custom' && $start_date && $end_date) {
            // For custom date range, use each day in the range
            $start = new DateTime($start_date);
            $end = new DateTime($end_date);
            $interval = new DateInterval('P1D');
            $daterange = new DatePeriod($start, $interval, $end);
            
            $days = array();
            foreach ($daterange as $date) {
                $days[] = $date->format('Y-m-d');
            }
            // Add the end date too
            $days[] = $end->format('Y-m-d');
        } else {
            // For predefined ranges, get appropriate number of days
            $days_count = 30; // Default
            
            switch ($date_range) {
                case '7days':
                    $days_count = 7;
                    break;
                case '30days':
                    $days_count = 30;
                    break;
                case '90days':
                    $days_count = 90;
                    break;
                case '1year':
                    $days_count = 365;
                    break;
                case 'all':
                    // For all time, we'll use the first and last attempt dates
                    $first_attempt = $wpdb->get_var("
                        SELECT MIN(date_created) FROM $attempts_table
                        WHERE 1=1 $quiz_constraint
                    ");
                    
                    if (!$first_attempt) {
                        $days_count = 30; // Default if no attempts
                    } else {
                        $first_date = new DateTime($first_attempt);
                        $current_date = new DateTime(current_time('mysql'));
                        $days_count = $first_date->diff($current_date)->days + 1;
                        
                        // Cap at 365 days to prevent too many data points
                        if ($days_count > 365) {
                            $days_count = 365;
                        }
                    }
                    break;
            }
            
            // Generate the days array
            $days = array();
            for ($i = $days_count - 1; $i >= 0; $i--) {
                $days[] = date('Y-m-d', strtotime("-$i days"));
            }
        }
        
        // Initialize chart data arrays
        $labels = array();
        $attempts_data = array();
        $passed_data = array();
        $scores_data = array();
        
        // Get data for each day
        foreach ($days as $day) {
            $day_start = $day . ' 00:00:00';
            $day_end = $day . ' 23:59:59';
            
            $query = $wpdb->prepare("
                SELECT 
                    COUNT(*) as attempts,
                    SUM(CASE WHEN passed = 1 THEN 1 ELSE 0 END) as passed,
                    AVG(score) as score
                FROM $attempts_table
                WHERE date_created BETWEEN %s AND %s $quiz_constraint
            ", $day_start, $day_end);
            
            $day_data = $wpdb->get_row($query);
            
            // Add formatted date to labels
            $labels[] = date('M j', strtotime($day));
            
            // Add data points
            $attempts_data[] = (int) $day_data->attempts;
            $passed_data[] = (int) $day_data->passed;
            $scores_data[] = round(floatval($day_data->score), 1);
        }
        
        // Get traffic sources
        $query = "
            SELECT 
                traffic_source,
                COUNT(*) as count
            FROM $attempts_table
            WHERE traffic_source IS NOT NULL AND traffic_source != '' $quiz_constraint $date_constraint
            GROUP BY traffic_source
            ORDER BY count DESC
            LIMIT 10
        ";
        
        $traffic_sources = $wpdb->get_results($query);
        
        // Get locations
        $query = "
            SELECT 
                location,
                COUNT(*) as count
            FROM $attempts_table
            WHERE location IS NOT NULL AND location != '' $quiz_constraint $date_constraint
            GROUP BY location
            ORDER BY count DESC
            LIMIT 10
        ";
        
        $locations = $wpdb->get_results($query);
        
        // Get top quizzes (only if not filtering by quiz)
        $top_quizzes = array();
        
        if ($quiz_id === 0) {
            $query = "
                SELECT 
                    quiz_id,
                    COUNT(*) as attempts
                FROM $attempts_table
                WHERE 1=1 $date_constraint
                GROUP BY quiz_id
                ORDER BY attempts DESC
                LIMIT 10
            ";
            
            $quiz_results = $wpdb->get_results($query);
            
            foreach ($quiz_results as $result) {
                $quiz_title = get_the_title($result->quiz_id);
                
                if (!$quiz_title) {
                    $quiz_title = sprintf(__('Quiz #%d', 'quizify-pro'), $result->quiz_id);
                }
                
                $top_quizzes[] = array(
                    'id' => $result->quiz_id,
                    'title' => $quiz_title,
                    'attempts' => (int) $result->attempts
                );
            }
        }
        
        // Get recent attempts
        $query = "
            SELECT 
                a.id,
                a.quiz_id,
                a.user_id,
                a.score,
                a.passed,
                a.time_spent,
                a.location,
                a.search_query,
                a.keywords,
                a.date_created
            FROM $attempts_table a
            WHERE 1=1 $quiz_constraint $date_constraint
            ORDER BY a.date_created DESC
            LIMIT 20
        ";
        
        $recent_results = $wpdb->get_results($query);
        $recent_attempts = array();
        
        foreach ($recent_results as $result) {
            $quiz_title = get_the_title($result->quiz_id);
            
            if (!$quiz_title) {
                $quiz_title = sprintf(__('Quiz #%d', 'quizify-pro'), $result->quiz_id);
            }
            
            // Get user info
            $user_name = __('Guest', 'quizify-pro');
            
            if ($result->user_id > 0) {
                $user = get_userdata($result->user_id);
                
                if ($user) {
                    $user_name = $user->display_name;
                } else {
                    $user_name = sprintf(__('User #%d', 'quizify-pro'), $result->user_id);
                }
            }
            
            $recent_attempts[] = array(
                'id' => $result->id,
                'quiz_id' => $result->quiz_id,
                'quiz_title' => $quiz_title,
                'user' => $user_name,
                'score' => (int) $result->score,
                'passed' => (bool) $result->passed,
                'time_spent' => (int) $result->time_spent,
                'location' => $result->location,
                'search_query' => $result->search_query,
                'keywords' => $result->keywords,
                'date' => date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($result->date_created))
            );
        }
        
        // Return all data
        return array(
            'total_attempts' => $total_attempts,
            'total_passed' => $total_passed,
            'average_score' => $average_score,
            'pass_rate' => $pass_rate,
            'chart' => array(
                'labels' => $labels,
                'attempts' => $attempts_data,
                'passed' => $passed_data,
                'scores' => $scores_data
            ),
            'traffic_sources' => $traffic_sources,
            'locations' => $locations,
            'top_quizzes' => $top_quizzes,
            'recent_attempts' => $recent_attempts
        );
    }

    /**
     * AJAX handler for searching analytics data
     *
     * @since    1.0.0
     */
    public function ajax_search_analytics() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'quizify_admin_nonce')) {
            wp_send_json_error(array('message' => 'Invalid nonce.'));
        }
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to access this data.'));
        }
        
        // Get search term
        if (!isset($_POST['search_term']) || empty($_POST['search_term'])) {
            wp_send_json_error(array('message' => 'No search term provided.'));
        }
        
        $search_term = sanitize_text_field($_POST['search_term']);
        
        // Get other parameters
        $date_range = isset($_POST['date_range']) ? sanitize_text_field($_POST['date_range']) : '30days';
        $quiz_id = isset($_POST['quiz_id']) ? absint($_POST['quiz_id']) : 0;
        $start_date = isset($_POST['start_date']) ? sanitize_text_field($_POST['start_date']) : '';
        $end_date = isset($_POST['end_date']) ? sanitize_text_field($_POST['end_date']) : '';
        
        // Log the search query
        $this->log_search_query($search_term, $quiz_id);
        
        // Perform search
        $results = $this->search_analytics_data($search_term, $date_range, $quiz_id, $start_date, $end_date);
        
        wp_send_json_success(array(
            'search_term' => $search_term,
            'results' => $results,
            'result_count' => count($results)
        ));
    }
    
    /**
     * Log a search query
     *
     * @since    1.0.0
     * @param    string    $search_term    The search term
     * @param    int       $quiz_id        The quiz ID (0 for all quizzes)
     */
    private function log_search_query($search_term, $quiz_id = 0) {
        global $wpdb;
        
        $user_id = get_current_user_id();
        
        $wpdb->insert(
            $wpdb->prefix . 'quizify_search_queries',
            array(
                'user_id' => $user_id,
                'quiz_id' => $quiz_id,
                'search_term' => $search_term,
                'date_created' => current_time('mysql')
            ),
            array('%d', '%d', '%s', '%s')
        );
    }
    
    /**
     * Search analytics data for the given term
     *
     * @since    1.0.0
     * @param    string    $search_term    The search term to look for
     * @param    string    $date_range     The date range to search in
     * @param    int       $quiz_id        The quiz ID (0 for all quizzes)
     * @param    string    $start_date     The custom start date (if date_range is 'custom')
     * @param    string    $end_date       The custom end date (if date_range is 'custom')
     * @return   array                     Array of matching results
     */
    private function search_analytics_data($search_term, $date_range, $quiz_id = 0, $start_date = '', $end_date = '') {
        global $wpdb;
        
        $attempts_table = $wpdb->prefix . 'quizify_attempts';
        
        // Set up date constraints
        $date_constraint = '';
        
        if ($date_range === 'custom' && $start_date && $end_date) {
            $start_date = date('Y-m-d 00:00:00', strtotime($start_date));
            $end_date = date('Y-m-d 23:59:59', strtotime($end_date));
            $date_constraint = $wpdb->prepare("AND a.date_created BETWEEN %s AND %s", $start_date, $end_date);
        } else {
            $current_date = current_time('mysql');
            
            switch ($date_range) {
                case '7days':
                    $date_constraint = $wpdb->prepare("AND a.date_created >= DATE_SUB(%s, INTERVAL 7 DAY)", $current_date);
                    break;
                case '30days':
                    $date_constraint = $wpdb->prepare("AND a.date_created >= DATE_SUB(%s, INTERVAL 30 DAY)", $current_date);
                    break;
                case '90days':
                    $date_constraint = $wpdb->prepare("AND a.date_created >= DATE_SUB(%s, INTERVAL 90 DAY)", $current_date);
                    break;
                case '1year':
                    $date_constraint = $wpdb->prepare("AND a.date_created >= DATE_SUB(%s, INTERVAL 1 YEAR)", $current_date);
                    break;
                case 'all':
                default:
                    $date_constraint = '';
                    break;
            }
        }
        
        // Quiz constraint
        $quiz_constraint = $quiz_id > 0 ? $wpdb->prepare("AND a.quiz_id = %d", $quiz_id) : '';
        
        // Prepare the search term for LIKE query
        $search_term_like = '%' . $wpdb->esc_like($search_term) . '%';
        
        // Search across multiple fields
        $query = $wpdb->prepare(
            "SELECT 
                a.id, 
                a.quiz_id, 
                a.user_id,
                a.score,
                a.passed,
                a.search_query,
                a.keywords,
                a.location,
                a.traffic_source,
                a.date_created,
                p.post_title as quiz_title
            FROM 
                $attempts_table a
            LEFT JOIN 
                {$wpdb->posts} p ON a.quiz_id = p.ID
            WHERE 
                (
                    p.post_title LIKE %s OR 
                    a.search_query LIKE %s OR 
                    a.keywords LIKE %s OR
                    a.location LIKE %s OR
                    a.traffic_source LIKE %s
                )
                $quiz_constraint
                $date_constraint
            ORDER BY 
                a.date_created DESC
            LIMIT 100",
            $search_term_like,
            $search_term_like,
            $search_term_like,
            $search_term_like,
            $search_term_like
        );
        
        $results = $wpdb->get_results($query);
        $search_results = array();
        
        if ($results) {
            foreach ($results as $result) {
                // Get user name
                $user_name = 'Anonymous';
                if ($result->user_id > 0) {
                    $user = get_userdata($result->user_id);
                    if ($user) {
                        $user_name = $user->display_name;
                    } else {
                        $user_name = sprintf(__('User #%d', 'quizify-pro'), $result->user_id);
                    }
                }
                
                $search_results[] = array(
                    'id' => $result->id,
                    'quiz_id' => $result->quiz_id,
                    'quiz_title' => $result->quiz_title,
                    'user_id' => $result->user_id,
                    'user_name' => $user_name,
                    'score' => (int) $result->score,
                    'passed' => (bool) $result->passed,
                    'search_query' => $result->search_query,
                    'keywords' => $result->keywords,
                    'location' => $result->location,
                    'traffic_source' => $result->traffic_source,
                    'date' => date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($result->date_created))
                );
            }
        }
        
        // Update the result count for this search term
        $this->update_search_result_count($search_term, count($search_results));
        
        return $search_results;
    }
    
    /**
     * Update the result count for a search term
     * 
     * @since    1.0.0
     * @param    string    $search_term    The search term
     * @param    int       $count          The number of results found
     */
    private function update_search_result_count($search_term, $count) {
        global $wpdb;
        
        $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}quizify_search_queries 
            SET result_count = %d 
            WHERE search_term = %s 
            ORDER BY id DESC 
            LIMIT 1",
            $count,
            $search_term
        ));
    }
    
    /**
     * Get user IP address
     *
     * @since    1.0.0
     * @return   string    The user's IP address
     */
    private function get_user_ip() {
        $ip = '127.0.0.1';
        
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        
        return sanitize_text_field($ip);
    }
}