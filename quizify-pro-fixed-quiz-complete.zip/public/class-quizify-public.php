<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @since      1.0.0
 *
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/public
 */

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and hooks for
 * the public-facing side of the site.
 *
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/public
 * @author     NetworkUstad Team
 */
class Quizify_Public {

    /**
     * Initialize the class.
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Nothing to do here
    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {
        wp_enqueue_style(
            'quizify-public',
            QUIZIFY_PRO_PLUGIN_URL . 'public/css/quizify-public.css',
            array(),
            QUIZIFY_PRO_VERSION
        );
    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {
        // Main public script
        wp_enqueue_script(
            'quizify-public',
            QUIZIFY_PRO_PLUGIN_URL . 'public/js/quizify-public.js',
            array('jquery'),
            QUIZIFY_PRO_VERSION,
            true
        );
        
        // Analytics tracking script
        wp_enqueue_script(
            'quizify-analytics',
            QUIZIFY_PRO_PLUGIN_URL . 'public/js/quizify-analytics.js',
            array('jquery', 'quizify-public'),
            QUIZIFY_PRO_VERSION,
            true
        );
        
        // Localize script for AJAX and translations
        wp_localize_script(
            'quizify-public',
            'quizify_public',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'plugin_url' => QUIZIFY_PRO_PLUGIN_URL, // Add plugin URL for asset loading
                'nonce' => wp_create_nonce('quizify_public_nonce'),
                'strings' => array(
                    'time_up' => __('Time\'s up! The quiz will be submitted automatically.', 'quizify-pro'),
                    'submit_confirm' => __('Are you sure you want to submit the quiz? You cannot change your answers after submission.', 'quizify-pro'),
                    'loading' => __('Loading...', 'quizify-pro'),
                    'error' => __('An error occurred. Please try again.', 'quizify-pro'),
                    'minutes' => __('minutes', 'quizify-pro'),
                    'seconds' => __('seconds', 'quizify-pro')
                )
            )
        );
    }

    /**
     * Register shortcodes.
     *
     * @since    1.0.0
     */
    public function register_shortcodes() {
        add_shortcode('quizify', array($this, 'quizify_shortcode'));
    }

    /**
     * Shortcode handler for [quizify].
     *
     * @since    1.0.0
     * @param    array     $atts    Shortcode attributes.
     * @return   string             Shortcode output.
     */
    public function quizify_shortcode($atts) {
        // Always ensure styles and scripts are loaded when shortcode is used
        $this->enqueue_styles();
        $this->enqueue_scripts();
        
        $atts = shortcode_atts(
            array(
                'id' => 0,
                'title' => 'true',
                'description' => 'true'
            ),
            $atts,
            'quizify'
        );
        
        // Check for valid quiz ID
        $quiz_id = absint($atts['id']);
        
        if (!$quiz_id) {
            return '<p class="quizify-error">' . __('Error: No quiz ID specified.', 'quizify-pro') . '</p>';
        }
        
        // Check if quiz exists
        $quiz = get_post($quiz_id);
        
        if (!$quiz || $quiz->post_type !== 'quizify_quiz' || $quiz->post_status !== 'publish') {
            return '<p class="quizify-error">' . __('Error: Invalid quiz ID or quiz is not published.', 'quizify-pro') . '</p>';
        }
        
        // Generate unique container ID
        $container_id = 'quizify-quiz-' . $quiz_id . '-' . uniqid();
        
        // Show/hide title and description based on attributes
        $show_title = filter_var($atts['title'], FILTER_VALIDATE_BOOLEAN);
        $show_description = filter_var($atts['description'], FILTER_VALIDATE_BOOLEAN);
        
        // Start output buffer
        ob_start();
        
        ?>
        <div id="<?php echo esc_attr($container_id); ?>" class="quizify-container" data-quiz-id="<?php echo esc_attr($quiz_id); ?>">
            <?php if ($show_title): ?>
                <h2 class="quizify-title"><?php echo esc_html($quiz->post_title); ?></h2>
            <?php endif; ?>
            
            <?php /* Description is now handled by the JavaScript to avoid duplication */ ?>
            
            <div class="quizify-loading"><?php _e('Loading quiz...', 'quizify-pro'); ?></div>
            <div class="quizify-content" style="display: none;"></div>
            <div class="quizify-results" style="display: none;"></div>
        </div>
        
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                if (typeof QuizPlayer !== 'undefined') {
                    new QuizPlayer($('#<?php echo esc_js($container_id); ?>'));
                } else {
                    console.error('QuizPlayer not defined. Check that quizify-public.js is loaded correctly.');
                }
            });
        </script>
        <?php
        
        // Return the buffered output
        return ob_get_clean();
    }

    /**
     * AJAX handler for getting quiz data.
     * 
     * @since    1.0.0
     */
    public function ajax_get_quiz() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'quizify_public_nonce')) {
            wp_send_json_error(array('message' => 'Invalid nonce.'));
        }
        
        // Check for quiz ID
        if (!isset($_POST['quiz_id'])) {
            wp_send_json_error(array('message' => 'No quiz ID provided.'));
        }
        
        $quiz_id = absint($_POST['quiz_id']);
        
        // Get quiz data
        $quiz_data = Quizify_Quiz::get_quiz_data($quiz_id);
        
        if (!$quiz_data) {
            wp_send_json_error(array('message' => 'Quiz not found.'));
        }
        
        wp_send_json_success($quiz_data);
    }

    /**
     * AJAX handler for submitting quiz.
     * 
     * @since    1.0.0
     */
    public function ajax_submit_quiz() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'quizify_public_nonce')) {
            wp_send_json_error(array('message' => 'Invalid nonce.'));
        }
        
        // Check for required data
        if (!isset($_POST['quiz_id']) || !isset($_POST['answers'])) {
            wp_send_json_error(array('message' => 'Missing required data.'));
        }
        
        $quiz_id = absint($_POST['quiz_id']);
        $answers = json_decode(stripslashes($_POST['answers']), true);
        
        if (!is_array($answers)) {
            wp_send_json_error(array('message' => 'Invalid answers format.'));
        }
        
        // Score the quiz
        $results = Quizify_Quiz::score_quiz($quiz_id, $answers);
        
        if (!$results) {
            wp_send_json_error(array('message' => 'Error scoring quiz.'));
        }
        
        wp_send_json_success($results);
    }
}