=== Quizify Pro ===
Contributors: networkustad
Tags: quiz, test, assessment, learning, education
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.2.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A premium quiz plugin for WordPress with advanced analytics features.

== Description ==

Quizify Pro is a comprehensive quiz solution for WordPress websites. Create engaging quizzes with various question types, timer functionality, and detailed analytics.

**Features:**

* Create unlimited quizzes with multiple question types
* Timer functionality for timed quizzes
* Randomize questions and answers
* Detailed analytics dashboard
* Track quiz attempts with geolocation data
* Show detailed results to quiz takers
* Export quiz results
* Customizable passing scores
* Customizable success/failure messages
* Mobile-friendly responsive design

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/quizify-pro` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Quizify menu that appears in your admin area to create quizzes
4. Use the shortcode `[quizify id="quiz_id"]` to display quizzes in your posts or pages

== Frequently Asked Questions ==

= How do I create a quiz? =

After installing and activating the plugin, go to Quizify > Add New in your WordPress admin. Give your quiz a title and description, then add questions and options in the Questions section. Configure quiz settings like time limit and passing score, then save your quiz.

= How do I display a quiz on my site? =

Use the shortcode `[quizify id="quiz_id"]` where quiz_id is the ID of your quiz. You can find this ID in the quiz editor or on the All Quizzes page.

= Can I customize the appearance of quizzes? =

Yes, the plugin uses your theme's styles by default but also includes its own styling to ensure good display across themes. Advanced customization can be done through CSS.

= Does the plugin track quiz statistics? =

Yes, Quizify Pro includes a detailed analytics dashboard that tracks quiz attempts, scores, pass rates, and even geographical location of quiz takers.

== Screenshots ==

1. Quiz Editor
2. Quiz Builder
3. Front-end Quiz Display
4. Results Screen
5. Analytics Dashboard

== Changelog ==

= 1.2.1 =
* Enhanced error handling with improved error messages
* Fixed 500 Internal Server Error during quiz submission
* Added robust error recovery with Try Again functionality
* Improved client-side JSON error handling
* Better error display styling

= 1.2.0 =
* Fixed quiz results calculation for all question types
* Improved saveAnswers() method
* Enhanced server-side scoring logic for multiple choice
* Fixed display of user and correct answers in results

= 1.1.0 =
* Added analytics dashboard
* Added geolocation tracking
* Enhanced user experience with animations
* Added mobile responsive improvements

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.2.1 =
This update fixes critical error handling issues during quiz submissions and provides better error messages and recovery options.

= 1.0.0 =
Initial release of Quizify Pro