<?php
/**
 * The plugin bootstrap file
 *
 * @link              https://networkustad.com
 * @since             1.0.0
 * @package           Quizify_Pro
 *
 * @wordpress-plugin
 * Plugin Name: Quizify Pro
 * Plugin URI: https://networkustad.com/quizify-pro
 * Description: A premium quiz plugin for WordPress with advanced analytics features.
 * Version: 1.2.1
 * Author: NetworkUstad Team
 * Author URI: https://networkustad.com
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: quizify-pro
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) exit;

/**
 * Currently plugin version.
 */
define('QUIZIFY_PRO_VERSION', '1.2.1');

/**
 * Define plugin directory path
 */
define('QUIZIFY_PRO_PLUGIN_DIR', plugin_dir_path(__FILE__));

/**
 * Define plugin directory URL
 */
define('QUIZIFY_PRO_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * The code that runs during plugin activation.
 */
function activate_quizify_pro() {
    require_once QUIZIFY_PRO_PLUGIN_DIR . 'includes/class-quizify-activator.php';
    Quizify_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_quizify_pro() {
    require_once QUIZIFY_PRO_PLUGIN_DIR . 'includes/class-quizify-deactivator.php';
    Quizify_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_quizify_pro');
register_deactivation_hook(__FILE__, 'deactivate_quizify_pro');

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require QUIZIFY_PRO_PLUGIN_DIR . 'includes/class-quizify.php';

/**
 * Begins execution of the plugin.
 *
 * @since    1.0.0
 */
function run_quizify_pro() {
    $plugin = new Quizify();
    $plugin->run();
}

run_quizify_pro();
