# Quizify Pro

A premium WordPress quiz plugin with advanced features and comprehensive error handling.

## Version 1.2.1 - Error Handling Update

This release focuses on enhancing error handling throughout the plugin to provide a better user experience when issues occur.

### Key Improvements

#### Server-Side Error Handling

- Added robust error handling with detailed error messages
- Improved validation of quiz IDs, questions, and answers
- Enhanced security with better nonce validation
- Added logging of error details for debugging
- Better handling of unexpected exceptions

#### Client-Side Error Handling

- Better error message extraction from server responses
- User-friendly error displays with clear messages
- Added "Try Again" functionality for error recovery
- Improved validation before quiz submission
- Enhanced console error logging for debugging

### Usage

1. Install and activate the plugin through the WordPress plugins screen
2. Go to Quizify > Add New to create a quiz
3. Configure quiz settings, add questions and options
4. Use the shortcode `[quizify id="quiz_id"]` to display the quiz on any post or page

### Shortcode Options

```
[quizify id="123" title="true" description="true"]
```

- `id`: The ID of the quiz to display (required)
- `title`: Whether to show the quiz title (true/false, default: true)
- `description`: Whether to show the quiz description (true/false, default: true)

## Support

For support, please contact our team at support@networkustad.com

## License

This plugin is licensed under the GPL v2 or later.

---

Copyright © 2025 NetworkUstad Team
