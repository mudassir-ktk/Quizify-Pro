<div class="wrap quizify-analytics-wrap">
    <h1><?php _e('Quiz Analytics', 'quizify-pro'); ?></h1>
    
    <div class="quizify-analytics-dashboard">
        <div class="quizify-analytics-header">
            <h2 class="quizify-analytics-title"><?php _e('Analytics Dashboard', 'quizify-pro'); ?></h2>
            
            <div class="quizify-analytics-filters">
                <div class="quizify-analytics-filter">
                    <label for="quizify-date-range"><?php _e('Date Range:', 'quizify-pro'); ?></label>
                    <select id="quizify-date-range">
                        <option value="7days"><?php _e('Last 7 Days', 'quizify-pro'); ?></option>
                        <option value="30days" selected><?php _e('Last 30 Days', 'quizify-pro'); ?></option>
                        <option value="90days"><?php _e('Last 90 Days', 'quizify-pro'); ?></option>
                        <option value="1year"><?php _e('Last Year', 'quizify-pro'); ?></option>
                        <option value="all"><?php _e('All Time', 'quizify-pro'); ?></option>
                        <option value="custom"><?php _e('Custom Range', 'quizify-pro'); ?></option>
                    </select>
                </div>
                
                <div class="quizify-analytics-filter">
                    <label for="quizify-filter-quiz"><?php _e('Quiz:', 'quizify-pro'); ?></label>
                    <select id="quizify-filter-quiz">
                        <option value="0"><?php _e('All Quizzes', 'quizify-pro'); ?></option>
                        <?php foreach ($quizzes as $quiz): ?>
                            <option value="<?php echo esc_attr($quiz->ID); ?>"><?php echo esc_html($quiz->post_title); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="quizify-analytics-filter quizify-search-filter">
                    <label for="quizify-search-term"><?php _e('Search Term:', 'quizify-pro'); ?></label>
                    <div class="quizify-search-container">
                        <input type="text" id="quizify-search-term" placeholder="<?php _e('Search analytics data...', 'quizify-pro'); ?>">
                        <button id="quizify-search-button" class="button quizify-search-button"><?php _e('Search', 'quizify-pro'); ?></button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="quizify-custom-date-container">
            <div class="quizify-custom-date-inputs">
                <div class="quizify-custom-date-field">
                    <label for="quizify-start-date"><?php _e('Start Date:', 'quizify-pro'); ?></label>
                    <input type="date" id="quizify-start-date">
                </div>
                
                <div class="quizify-custom-date-field">
                    <label for="quizify-end-date"><?php _e('End Date:', 'quizify-pro'); ?></label>
                    <input type="date" id="quizify-end-date">
                </div>
                
                <button id="quizify-apply-custom-date" class="button"><?php _e('Apply', 'quizify-pro'); ?></button>
            </div>
        </div>
        
        <div class="quizify-analytics-cards">
            <div class="quizify-analytics-card">
                <h3 class="quizify-analytics-card-title"><?php _e('Total Attempts', 'quizify-pro'); ?></h3>
                <p class="quizify-analytics-card-value" id="quizify-total-attempts">0</p>
            </div>
            
            <div class="quizify-analytics-card">
                <h3 class="quizify-analytics-card-title"><?php _e('Total Passed', 'quizify-pro'); ?></h3>
                <p class="quizify-analytics-card-value" id="quizify-total-passed">0</p>
            </div>
            
            <div class="quizify-analytics-card">
                <h3 class="quizify-analytics-card-title"><?php _e('Pass Rate', 'quizify-pro'); ?></h3>
                <p class="quizify-analytics-card-value" id="quizify-pass-rate">0%</p>
            </div>
            
            <div class="quizify-analytics-card">
                <h3 class="quizify-analytics-card-title"><?php _e('Average Score', 'quizify-pro'); ?></h3>
                <p class="quizify-analytics-card-value" id="quizify-average-score">0%</p>
            </div>
        </div>
        
        <div class="quizify-analytics-charts">
            <div class="quizify-analytics-chart">
                <h3 class="quizify-analytics-chart-title"><?php _e('Quiz Attempts', 'quizify-pro'); ?></h3>
                <div class="quizify-chart-container">
                    <canvas id="quizify-attempts-chart"></canvas>
                </div>
            </div>
            
            <div class="quizify-analytics-chart">
                <h3 class="quizify-analytics-chart-title"><?php _e('Average Scores', 'quizify-pro'); ?></h3>
                <div class="quizify-chart-container">
                    <canvas id="quizify-scores-chart"></canvas>
                </div>
            </div>
        </div>
        
        <div class="quizify-analytics-columns">
            <div class="quizify-analytics-column">
                <h3><?php _e('Top Quizzes', 'quizify-pro'); ?></h3>
                <div class="quizify-analytics-table-container">
                    <table class="quizify-analytics-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th><?php _e('Quiz', 'quizify-pro'); ?></th>
                                <th><?php _e('Attempts', 'quizify-pro'); ?></th>
                            </tr>
                        </thead>
                        <tbody id="quizify-top-quizzes-tbody">
                            <tr>
                                <td colspan="3" class="quizify-no-data"><?php _e('Loading...', 'quizify-pro'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="quizify-analytics-column">
                <h3><?php _e('Traffic Sources', 'quizify-pro'); ?></h3>
                <div class="quizify-analytics-table-container">
                    <table class="quizify-analytics-table">
                        <thead>
                            <tr>
                                <th><?php _e('Source', 'quizify-pro'); ?></th>
                                <th><?php _e('Attempts', 'quizify-pro'); ?></th>
                            </tr>
                        </thead>
                        <tbody id="quizify-traffic-sources-tbody">
                            <tr>
                                <td colspan="2" class="quizify-no-data"><?php _e('Loading...', 'quizify-pro'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="quizify-analytics-columns">
            <div class="quizify-analytics-column">
                <h3><?php _e('Recent Attempts', 'quizify-pro'); ?></h3>
                <div class="quizify-analytics-table-container">
                    <table class="quizify-analytics-table">
                        <thead>
                            <tr>
                                <th><?php _e('Quiz', 'quizify-pro'); ?></th>
                                <th><?php _e('User', 'quizify-pro'); ?></th>
                                <th><?php _e('Score', 'quizify-pro'); ?></th>
                                <th><?php _e('Result', 'quizify-pro'); ?></th>
                                <th><?php _e('Location', 'quizify-pro'); ?></th>
                                <th><?php _e('Date', 'quizify-pro'); ?></th>
                            </tr>
                        </thead>
                        <tbody id="quizify-recent-attempts-tbody">
                            <tr>
                                <td colspan="6" class="quizify-no-data"><?php _e('Loading...', 'quizify-pro'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="quizify-analytics-column">
                <h3><?php _e('Locations', 'quizify-pro'); ?></h3>
                <div class="quizify-analytics-table-container">
                    <table class="quizify-analytics-table">
                        <thead>
                            <tr>
                                <th><?php _e('Location', 'quizify-pro'); ?></th>
                                <th><?php _e('Attempts', 'quizify-pro'); ?></th>
                            </tr>
                        </thead>
                        <tbody id="quizify-locations-tbody">
                            <tr>
                                <td colspan="2" class="quizify-no-data"><?php _e('Loading...', 'quizify-pro'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Search Results Section -->
        <div id="quizify-search-results-section" class="quizify-search-results-section" style="display: none;">
            <div class="quizify-analytics-column">
                <h3><?php _e('Search Results', 'quizify-pro'); ?> <span id="quizify-search-query-display"></span></h3>
                <div class="quizify-analytics-table-container">
                    <table class="quizify-analytics-table">
                        <thead>
                            <tr>
                                <th><?php _e('Quiz', 'quizify-pro'); ?></th>
                                <th><?php _e('User', 'quizify-pro'); ?></th>
                                <th><?php _e('Query', 'quizify-pro'); ?></th>
                                <th><?php _e('Date', 'quizify-pro'); ?></th>
                                <th><?php _e('Details', 'quizify-pro'); ?></th>
                            </tr>
                        </thead>
                        <tbody id="quizify-search-results-tbody">
                            <tr>
                                <td colspan="5" class="quizify-no-data"><?php _e('No search results found.', 'quizify-pro'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="quizify-analytics-loading">
            <div class="quizify-spinner-text">Loading data...</div>
        </div>
    </div>
</div>