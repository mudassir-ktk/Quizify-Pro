/**
 * Quizify Analytics JavaScript
 * 
 * Handles quiz usage analytics in the admin area
 */
(function($) {
    'use strict';
    
    /**
     * Initialize analytics when document is ready
     */
    $(document).ready(function() {
        if ($('.quizify-analytics-dashboard').length) {
            initAnalyticsDashboard();
        }
    });
    
    /**
     * Initialize the analytics dashboard
     */
    function initAnalyticsDashboard() {
        console.log('Initializing analytics dashboard with improved error handling');
        
        // Show/hide custom date inputs based on date range selection
        $('#quizify-filter-date-range').on('change', function() {
            if ($(this).val() === 'custom') {
                $('.quizify-custom-date-container').slideDown();
            } else {
                $('.quizify-custom-date-container').slideUp();
                loadAnalyticsData();
            }
        });
        
        // Initialize date pickers
        $('#quizify-filter-start-date, #quizify-filter-end-date').datepicker({
            dateFormat: 'yy-mm-dd',
            maxDate: 0
        });
        
        // Set initial date range state
        if ($('#quizify-filter-date-range').val() !== 'custom') {
            $('.quizify-custom-date-container').hide();
        }
        
        // Handle quiz filter changes
        $('#quizify-filter-quiz').on('change', function() {
            loadAnalyticsData();
        });
        
        // Handle custom date range apply button
        $('#quizify-apply-date-filter').on('click', function(e) {
            e.preventDefault();
            loadAnalyticsData();
        });
        
        // Add error message container if it doesn't exist
        if ($('.quizify-error-message').length === 0) {
            $('.quizify-analytics-dashboard').prepend(
                '<div class="quizify-error-message" style="display:none;"></div>'
            );
        }
        
        // Handle search button click
        $('#quizify-search-button').on('click', function(e) {
            e.preventDefault();
            performSearch();
        });
        
        // Handle Enter key in search input
        $('#quizify-search-term').on('keypress', function(e) {
            if (e.which === 13) { // Enter key
                e.preventDefault();
                performSearch();
            }
        });
        
        // Load initial data
        loadAnalyticsData();
    }
    
    /**
     * Perform search on analytics data
     */
    function performSearch() {
        const searchTerm = $('#quizify-search-term').val().trim();
        
        if (!searchTerm) {
            showError('Please enter a search term.');
            return;
        }
        
        console.log('Performing search for:', searchTerm);
        showLoading();
        
        // Get the AJAX URL
        const ajaxUrl = (typeof ajaxurl !== 'undefined') ? ajaxurl : 
                      (typeof quizify_admin !== 'undefined' && quizify_admin.ajax_url ? 
                       quizify_admin.ajax_url : 
                       '/wp-admin/admin-ajax.php');
        
        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                action: 'quizify_search_analytics',
                nonce: typeof quizify_admin !== 'undefined' && quizify_admin.nonce ? quizify_admin.nonce : '',
                search_term: searchTerm,
                date_range: $('#quizify-filter-date-range').val(),
                quiz_id: $('#quizify-filter-quiz').val(),
                start_date: $('#quizify-filter-start-date').val(),
                end_date: $('#quizify-filter-end-date').val()
            },
            dataType: 'json',
            success: function(response) {
                hideLoading();
                console.log('Search response:', response);
                
                if (response && response.success) {
                    updateSearchResults(response.data, searchTerm);
                } else {
                    let errorMessage = 'Error performing search.';
                    
                    if (response && response.data && response.data.message) {
                        errorMessage = response.data.message;
                    }
                    
                    showError(errorMessage);
                }
            },
            error: function(xhr, status, error) {
                hideLoading();
                console.error('Search AJAX request failed:', {xhr, status, error});
                showError('Error performing search. Please try again.');
            },
            timeout: 15000
        });
    }
    
    /**
     * Update search results display
     */
    function updateSearchResults(data, searchTerm) {
        // Update the search query display
        $('#quizify-search-query-display').text(`for "${searchTerm}"`);
        
        // Clear previous results
        const $resultsBody = $('#quizify-search-results-tbody');
        $resultsBody.empty();
        
        // Show search results section
        $('#quizify-search-results-section').show();
        
        // If no results, show "no results" message
        if (!data.results || data.results.length === 0) {
            $resultsBody.html('<tr><td colspan="5" class="quizify-no-data">No search results found.</td></tr>');
            return;
        }
        
        // Add each search result to the table
        data.results.forEach(function(result, index) {
            const row = `
                <tr>
                    <td>${highlightMatch(escapeHTML(result.quiz_title || 'Unknown'), searchTerm)}</td>
                    <td>${highlightMatch(escapeHTML(result.user_name || 'Anonymous'), searchTerm)}</td>
                    <td>${highlightMatch(escapeHTML(result.search_query || ''), searchTerm)}</td>
                    <td>${escapeHTML(result.date || '')}</td>
                    <td>
                        <button class="quizify-search-details-button" 
                                data-id="${escapeHTML(result.id || '')}"
                                data-quiz="${escapeHTML(result.quiz_id || '')}">
                            View Details
                        </button>
                    </td>
                </tr>
            `;
            
            $resultsBody.append(row);
        });
        
        // Add event handlers for the "View Details" buttons
        $('.quizify-search-details-button').on('click', function() {
            const id = $(this).data('id');
            const quizId = $(this).data('quiz');
            // TODO: Add functionality to view details - for now just log it
            console.log(`View details for ID: ${id}, Quiz: ${quizId}`);
            alert(`Details coming soon for search result ID: ${id}`);
        });
    }
    
    /**
     * Highlight search matches in text
     */
    function highlightMatch(text, searchTerm) {
        if (!text || !searchTerm) return text;
        
        // Case insensitive search
        const regex = new RegExp('(' + escapeRegExp(searchTerm) + ')', 'gi');
        return text.replace(regex, '<span class="quizify-search-highlight">$1</span>');
    }
    
    /**
     * Escape string for use in RegExp
     */
    function escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    
    /**
     * Escape HTML special characters
     */
    function escapeHTML(str) {
        if (!str) return '';
        return str
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }
    
    /**
     * Load analytics data via AJAX
     */
    function loadAnalyticsData() {
        const filters = {
            date_range: $('#quizify-filter-date-range').val(),
            quiz_id: $('#quizify-filter-quiz').val(),
            start_date: $('#quizify-filter-start-date').val(),
            end_date: $('#quizify-filter-end-date').val()
        };
        
        showLoading();
        
        // Check if ajaxurl is defined, or use fallback
        const ajaxUrl = (typeof ajaxurl !== 'undefined') ? ajaxurl : 
                      (typeof quizify_admin !== 'undefined' && quizify_admin.ajax_url ? 
                       quizify_admin.ajax_url : 
                       '/wp-admin/admin-ajax.php');

        console.log('Loading analytics data with filters:', filters);
        
        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                action: 'quizify_get_analytics_data',
                nonce: typeof quizify_admin !== 'undefined' && quizify_admin.nonce ? quizify_admin.nonce : '',
                date_range: filters.date_range,
                quiz_id: filters.quiz_id,
                start_date: filters.start_date,
                end_date: filters.end_date
            },
            dataType: 'json',
            success: function(response) {
                console.log('AJAX response received:', response);
                
                // Always hide loading to prevent infinite spinner
                hideLoading();
                
                if (response && response.success) {
                    updateDashboard(response.data);
                } else {
                    // Handle unsuccessful response
                    let errorMessage = 'Error loading analytics data.';
                    
                    if (response && response.data && response.data.message) {
                        errorMessage = response.data.message;
                    }
                    
                    showError(errorMessage);
                    console.error('AJAX error response:', response);
                    
                    // If we get an error, show empty dashboard rather than spinner
                    updateDashboard(null);
                }
            },
            error: function(xhr, status, error) {
                // Always hide loading to prevent infinite spinner
                hideLoading();
                
                console.error('AJAX request failed:', {xhr, status, error});
                showError('Error loading analytics data. Please try again.');
                
                // Display error details in console for debugging
                try {
                    if (xhr && xhr.responseText) {
                        const errorDetails = JSON.parse(xhr.responseText);
                        console.error('Server error details:', errorDetails);
                    }
                } catch(e) {
                    console.error('Could not parse error response:', xhr.responseText);
                }
                
                // If AJAX fails completely, still update with empty data
                updateDashboard(null);
            },
            // Set timeout to prevent hanging request
            timeout: 15000
        });
    }
    
    /**
     * Update the dashboard with data
     */
    function updateDashboard(data) {
        // Ensure data is an object
        if (!data || typeof data !== 'object') {
            data = {
                total_attempts: 0,
                total_passed: 0,
                average_score: 0,
                pass_rate: 0,
                chart: {
                    labels: [],
                    attempts: [],
                    passed: [],
                    scores: []
                },
                top_quizzes: [],
                traffic_sources: [],
                locations: [],
                recent_attempts: []
            };
            console.error('Invalid data received');
        }
        
        // Update summary stats
        $('#quizify-total-attempts').text(data.total_attempts || 0);
        $('#quizify-total-passed').text(data.total_passed || 0);
        $('#quizify-average-score').text((data.average_score || 0) + '%');
        $('#quizify-pass-rate').text((data.pass_rate || 0) + '%');
        
        // Update charts
        updateCharts(data);
        
        // Update tables
        updateTables(data);
        
        console.log('Dashboard updated with data:', data);
    }
    
    /**
     * Update charts with data
     */
    function updateCharts(data) {
        // Create attempts chart
        if (data.chart && data.chart.labels) {
            const attemptsCtx = document.getElementById('quizify-attempts-chart').getContext('2d');
            
            // Destroy existing chart if it exists
            if (window.attemptsChart) {
                window.attemptsChart.destroy();
            }
            
            // Create new chart with enhanced interactivity
            window.attemptsChart = new Chart(attemptsCtx, {
                type: 'bar',
                data: {
                    labels: data.chart.labels,
                    datasets: [{
                        label: 'Attempts',
                        data: data.chart.attempts,
                        backgroundColor: 'rgba(54, 162, 235, 0.5)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }, {
                        label: 'Passed',
                        data: data.chart.passed,
                        backgroundColor: 'rgba(75, 192, 192, 0.5)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                        mode: 'index',
                        intersect: false,
                    },
                    plugins: {
                        tooltip: {
                            enabled: true,
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            titleFont: {
                                size: 14
                            },
                            bodyFont: {
                                size: 13
                            },
                            padding: 10,
                            cornerRadius: 4
                        },
                        legend: {
                            position: 'top',
                            labels: {
                                usePointStyle: true,
                                padding: 15,
                                font: {
                                    size: 12
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        }
                    }
                }
            });
        }
        
        // Create scores chart
        if (data.chart && data.chart.labels) {
            const scoresCtx = document.getElementById('quizify-scores-chart').getContext('2d');
            
            // Destroy existing chart if it exists
            if (window.scoresChart) {
                window.scoresChart.destroy();
            }
            
            // Create new chart with enhanced interactivity
            window.scoresChart = new Chart(scoresCtx, {
                type: 'line',
                data: {
                    labels: data.chart.labels,
                    datasets: [{
                        label: 'Average Score',
                        data: data.chart.scores,
                        fill: false,
                        backgroundColor: 'rgba(153, 102, 255, 0.5)',
                        borderColor: 'rgba(153, 102, 255, 1)',
                        tension: 0.1,
                        pointBackgroundColor: 'rgba(153, 102, 255, 1)',
                        pointRadius: 4,
                        pointHoverRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                        mode: 'index',
                        intersect: false,
                    },
                    plugins: {
                        tooltip: {
                            enabled: true,
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            titleFont: {
                                size: 14
                            },
                            bodyFont: {
                                size: 13
                            },
                            padding: 10,
                            cornerRadius: 4,
                            callbacks: {
                                label: function(context) {
                                    return 'Average Score: ' + context.parsed.y + '%';
                                }
                            }
                        },
                        legend: {
                            position: 'top',
                            labels: {
                                usePointStyle: true,
                                padding: 15,
                                font: {
                                    size: 12
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            ticks: {
                                callback: function(value) {
                                    return value + '%';
                                }
                            }
                        }
                    }
                }
            });
        }
    }
    
    /**
     * Update tables with data
     */
    function updateTables(data) {
        // Update Top Quizzes table
        if (data.top_quizzes && data.top_quizzes.length > 0) {
            let topQuizzesHtml = '';
            data.top_quizzes.forEach((quiz, index) => {
                topQuizzesHtml += `
                    <tr>
                        <td>${index + 1}</td>
                        <td>${quiz.title}</td>
                        <td>${quiz.attempts}</td>
                    </tr>
                `;
            });
            $('#quizify-top-quizzes-tbody').html(topQuizzesHtml);
        } else {
            $('#quizify-top-quizzes-tbody').html(`<tr><td colspan="3" class="quizify-no-data">No data available</td></tr>`);
        }

        // Update Traffic Sources table
        if (data.traffic_sources && data.traffic_sources.length > 0) {
            let trafficSourcesHtml = '';
            data.traffic_sources.forEach(source => {
                trafficSourcesHtml += `
                    <tr>
                        <td>${source.traffic_source || 'Direct'}</td>
                        <td>${source.count}</td>
                    </tr>
                `;
            });
            $('#quizify-traffic-sources-tbody').html(trafficSourcesHtml);
        } else {
            $('#quizify-traffic-sources-tbody').html(`<tr><td colspan="2" class="quizify-no-data">No data available</td></tr>`);
        }

        // Update Locations table
        if (data.locations && data.locations.length > 0) {
            let locationsHtml = '';
            data.locations.forEach(location => {
                locationsHtml += `
                    <tr>
                        <td>${location.location || 'Unknown'}</td>
                        <td>${location.count}</td>
                    </tr>
                `;
            });
            $('#quizify-locations-tbody').html(locationsHtml);
        } else {
            $('#quizify-locations-tbody').html(`<tr><td colspan="2" class="quizify-no-data">No data available</td></tr>`);
        }

        // Update Recent Attempts table
        if (data.recent_attempts && data.recent_attempts.length > 0) {
            let recentAttemptsHtml = '';
            data.recent_attempts.forEach(attempt => {
                const resultClass = attempt.passed ? 'quizify-pass' : 'quizify-fail';
                const resultText = attempt.passed ? 'Pass' : 'Fail';
                
                recentAttemptsHtml += `
                    <tr>
                        <td>${attempt.quiz_title}</td>
                        <td>${attempt.user}</td>
                        <td>${attempt.score}%</td>
                        <td><span class="${resultClass}">${resultText}</span></td>
                        <td>${attempt.location || 'Unknown'}</td>
                        <td>${attempt.date}</td>
                    </tr>
                `;
            });
            $('#quizify-recent-attempts-tbody').html(recentAttemptsHtml);
        } else {
            $('#quizify-recent-attempts-tbody').html(`<tr><td colspan="6" class="quizify-no-data">No data available</td></tr>`);
        }
    }
    
    /**
     * Show loading indicator
     */
    function showLoading() {
        console.log('Showing loading indicator');
        $('.quizify-loading, .quizify-analytics-loading').fadeIn(200);
    }
    
    /**
     * Hide loading indicator
     */
    function hideLoading() {
        console.log('Hiding loading indicator');
        $('.quizify-loading, .quizify-analytics-loading').fadeOut(200);
    }
    
    /**
     * Show error message with improved visibility
     */
    function showError(message) {
        // Create error container if it doesn't exist
        if ($('.quizify-error-message').length === 0) {
            $('.quizify-analytics-dashboard').prepend('<div class="quizify-error-message"></div>');
        }
        
        const errorContainer = $('.quizify-error-message');
        
        // Stop any existing animation and clear previous timeout
        errorContainer.stop(true, true);
        clearTimeout(window.errorTimeoutId);
        
        // Update message and show with animation
        errorContainer.html(`<strong>Error:</strong> ${message}`).fadeIn(300);
        
        // Set timeout to hide message after delay
        window.errorTimeoutId = setTimeout(function() {
            errorContainer.fadeOut(500);
        }, 7000);
        
        // Log error to console for debugging
        console.error('Quizify Error:', message);
    }
    
})(jQuery);