<?php
/**
 * The plugin bootstrap file
 *
 * @link              https://networkustad.com
 * @since             1.0.0
 * @package           Quizify_Pro
 *
 * @wordpress-plugin
 * Plugin Name: Quizify
 * Plugin URI: https://networkustad.com/quizify
 * Description: A quiz plugin for WordPress with essential features.
 * Version: 1.2.1
 * Author: NetworkUstad Team
 * Author URI: https://networkustad.com
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: quizify-pro
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) exit;

/**
 * Currently plugin version.
 */
define('QUIZIFY_PRO_VERSION', '1.2.1');

/**
 * Define plugin directory path
 */
define('QUIZIFY_PRO_PLUGIN_DIR', plugin_dir_path(__FILE__));

/**
 * Define plugin directory URL
 */
define('QUIZIFY_PRO_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Development mode for testing
 * Set to true to enable all premium features without a license key
 * IMPORTANT: Set to false in production!
 */
define('QUIZIFY_DEV_MODE', true);

/**
 * The code that runs during plugin activation.
 */
function activate_quizify_pro() {
    require_once QUIZIFY_PRO_PLUGIN_DIR . 'includes/class-quizify-activator.php';
    Quizify_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_quizify_pro() {
    require_once QUIZIFY_PRO_PLUGIN_DIR . 'includes/class-quizify-deactivator.php';
    Quizify_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_quizify_pro');
register_deactivation_hook(__FILE__, 'deactivate_quizify_pro');

/**
 * Load the Features class for managing free and premium features
 */
require QUIZIFY_PRO_PLUGIN_DIR . 'includes/class-quizify-features.php';

/**
 * Load the License class for managing license activation
 */
require QUIZIFY_PRO_PLUGIN_DIR . 'includes/class-quizify-license.php';

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require QUIZIFY_PRO_PLUGIN_DIR . 'includes/class-quizify.php';

/**
 * Begins execution of the plugin.
 *
 * @since    1.0.0
 */
function run_quizify_pro() {
    // Initialize the features manager
    new Quizify_Features();
    
    // Initialize the license manager
    new Quizify_License();
    
    // Initialize the plugin
    $plugin = new Quizify();
    $plugin->run();
}

run_quizify_pro();

/**
 * Changes the plugin name and icon when premium is activated
 */
function quizify_modify_plugin_info() {
    if (!is_admin()) {
        return;
    }
    
    // Check if pro version is active
    if (get_option('quizify_is_pro') || get_option('quizify_pro_upgrade_pending')) {
        // Change the plugin name in admin area
        add_filter('all_plugins', function($plugins) {
            $plugin_file = plugin_basename(__FILE__);
            if (isset($plugins[$plugin_file])) {
                $plugins[$plugin_file]['Name'] = 'Quizify Pro';
                $plugins[$plugin_file]['Description'] = 'A premium quiz plugin for WordPress with advanced analytics features.';
            }
            return $plugins;
        });
        
        // Change the plugin icon in admin area
        add_action('admin_head', function() {
            ?>
            <style>
                /* Replace the icon for Quizify in the plugins list when Pro is active */
                .plugins-php tr[data-slug="quizify-pro"] .plugin-icon,
                .plugins-php tr[data-plugin="quizify-pro/quizify-pro.php"] .plugin-icon {
                    background-image: url('<?php echo QUIZIFY_PRO_PLUGIN_URL; ?>premium-icon.png') !important;
                    background-size: cover !important;
                }
                
                /* Change the admin menu icon */
                #toplevel_page_quizify_admin .wp-menu-image:before {
                    content: '';
                    background-image: url('<?php echo QUIZIFY_PRO_PLUGIN_URL; ?>premium-icon-small.png');
                    background-size: 18px 18px;
                    background-repeat: no-repeat;
                    background-position: center;
                    width: 20px;
                    height: 20px;
                    display: inline-block;
                }
            </style>
            <?php
        });
        
        // Change the admin page title
        add_filter('admin_title', function($admin_title, $title) {
            if (strpos($title, 'Quizify') !== false) {
                return str_replace('Quizify', 'Quizify Pro', $admin_title);
            }
            return $admin_title;
        }, 10, 2);
    }
}
add_action('admin_init', 'quizify_modify_plugin_info');

/**
 * Check for Pro upgrade and handle the upgrade process.
 * This code runs on every admin page load to check if a pro upgrade is pending.
 */
function quizify_check_for_pro_upgrade() {
    // Only run in admin area
    if (!is_admin()) {
        return;
    }
    
    // Check if an upgrade is pending
    if (get_option('quizify_pro_upgrade_pending')) {
        // Add an admin notice about the upgrade
        add_action('admin_notices', 'quizify_upgrading_admin_notice');
        
        // Schedule the upgrade process
        if (!wp_next_scheduled('quizify_process_pro_upgrade')) {
            wp_schedule_single_event(time() + 5, 'quizify_process_pro_upgrade');
        }
    }
}
add_action('admin_init', 'quizify_check_for_pro_upgrade');

/**
 * Display an admin notice during the upgrade process
 */
function quizify_upgrading_admin_notice() {
    ?>
    <div class="notice notice-info">
        <p><strong><?php _e('Quizify Pro Upgrade', 'quizify-pro'); ?></strong></p>
        <p><?php _e('Your license key has been validated! Quizify is now upgrading to the Pro version. This may take a few moments.', 'quizify-pro'); ?></p>
    </div>
    <?php
}

/**
 * Process the upgrade from free to pro version
 */
function quizify_process_pro_upgrade() {
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/plugin.php');
    require_once(ABSPATH . 'wp-admin/includes/class-wp-upgrader.php');
    require_once(ABSPATH . 'wp-admin/includes/plugin-install.php');
    
    // Get filesystem credentials
    $credentials = request_filesystem_credentials('');
    if (false === $credentials || !WP_Filesystem($credentials)) {
        // Failed to get filesystem access, display a notice and exit
        add_action('admin_notices', function() {
            ?>
            <div class="notice notice-error">
                <p><strong><?php _e('Quizify Pro Upgrade Failed', 'quizify-pro'); ?></strong></p>
                <p><?php _e('Could not access the filesystem. Please check file permissions or contact your hosting provider.', 'quizify-pro'); ?></p>
            </div>
            <?php
        });
        return;
    }
    
    // Unlock all premium features immediately based on the valid license
    update_option('quizify_is_pro', true);
    
    // Plugin paths
    $plugin_slug = 'quizify-pro';
    $plugin_dir = WP_PLUGIN_DIR . '/' . $plugin_slug;
    
    // Connect to your server API to get the download URL for the pro version
    // For example: https://networkustad.com/api/get-latest-pro-version.php
    $download_url = 'https://networkustad.com/api/get-latest-pro-version?license_key=' . get_option('quizify_license_key');
    
    // For testing, use the upgrade server URL with the plugin files
    if (defined('QUIZIFY_DEV_MODE') && QUIZIFY_DEV_MODE) {
        $download_url = 'https://networkustad.com/downloads/quizify-pro-latest.zip';
    }
    
    // Prepare for installation
    $upgrader = new Plugin_Upgrader(new Automatic_Upgrader_Skin());
    
    // Attempt to install/upgrade the plugin
    $result = $upgrader->install($download_url, array(
        'overwrite_package' => true // Overwrite if the plugin already exists
    ));
    
    if (is_wp_error($result) || !$result) {
        // Log the error and notify the user
        add_action('admin_notices', function() use ($result) {
            ?>
            <div class="notice notice-error">
                <p><strong><?php _e('Quizify Pro Upgrade Failed', 'quizify-pro'); ?></strong></p>
                <p><?php echo is_wp_error($result) ? $result->get_error_message() : __('The upgrade process failed unexpectedly.', 'quizify-pro'); ?></p>
            </div>
            <?php
        });
        return;
    }
    
    // Success - mark the upgrade as complete
    update_option('quizify_pro_upgrade_pending', false);
    update_option('quizify_pro_upgraded', true);
    
    // Add a success notice
    add_action('admin_notices', function() {
        ?>
        <div class="notice notice-success">
            <p><strong><?php _e('Quizify Pro Upgrade Complete!', 'quizify-pro'); ?></strong></p>
            <p><?php _e('Your plugin has been successfully upgraded to Quizify Pro. All premium features are now available!', 'quizify-pro'); ?></p>
        </div>
        <?php
    });
    
    // Activate the pro plugin if needed
    activate_plugin($plugin_slug . '/' . $plugin_slug . '.php');
}
add_action('quizify_process_pro_upgrade', 'quizify_process_pro_upgrade');
