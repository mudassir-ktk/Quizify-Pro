/**
 * Quizify Public JavaScript
 * 
 * Handles quiz display and interaction on the front-end
 */
(function($) {
    'use strict';
    
    /**
     * Quiz Player class for handling quiz interaction
     */
    class QuizPlayer {
        /**
         * Initialize the quiz player
         */
        constructor(container) {
            this.container = container;
            this.quizId = container.data('quiz-id');
            this.currentQuestion = 0;
            this.timer = null;
            this.timerSeconds = 0;
            this.quizData = null;
            this.answers = {};
            
            this.cacheElements();
            this.bindEvents();
            this.initQuiz();
        }
        
        /**
         * Cache DOM elements
         */
        cacheElements() {
            this.content = this.container.find('.quizify-content');
            this.results = this.container.find('.quizify-results');
            this.loading = this.container.find('.quizify-loading');
            this.startContainer = this.container.find('.quizify-start-container');
            this.startButton = this.container.find('.quizify-start-button');
        }
        
        /**
         * Bind event handlers
         */
        bindEvents() {
            this.container.on('click', '.quizify-start-button', this.startQuiz.bind(this));
            this.container.on('click', '.quizify-prev-button', (e) => this.navigate(e, 'prev'));
            
            // Modified next button to show explanation before navigating
            this.container.on('click', '.quizify-next-button', (e) => {
                // Save answers and show explanation before navigating
                const questionId = this.content.find('.quizify-question').data('question-id');
                this.saveAnswers();
                this.showExplanation(questionId);
                
                // Add a small delay before navigating to the next question
                setTimeout(() => {
                    this.navigate(e, 'next');
                }, 1500);
            });
            
            // Answer selection events to show explanations
            this.container.on('change', 'input[type="radio"], input[type="checkbox"]', (e) => {
                const questionId = this.content.find('.quizify-question').data('question-id');
                this.showExplanation(questionId);
            });
            
            // For text and paragraph inputs, show explanation on blur (when user clicks away)
            this.container.on('blur', 'input[type="text"], textarea', (e) => {
                if ($(e.target).val().trim()) {
                    const questionId = this.content.find('.quizify-question').data('question-id');
                    this.showExplanation(questionId);
                }
            });
            
            // Modified submit button to show explanation before submitting
            this.container.on('click', '.quizify-submit-button', (e) => {
                // Show explanation before submitting
                const questionId = this.content.find('.quizify-question').data('question-id');
                this.saveAnswers();
                this.showExplanation(questionId);
                
                // Add a small delay before submitting
                setTimeout(() => {
                    this.submitQuiz(e);
                }, 1500);
            });
            
            this.container.on('click', '.quizify-retake-button', this.retakeQuiz.bind(this));
        }
        
        /**
         * Initialize the quiz
         */
        initQuiz() {
            this.loadQuizData();
        }
        
        /**
         * Start the quiz
         */
        startQuiz(e) {
            e.preventDefault();
            
            // Hide the start container and show the quiz content
            this.startContainer.hide();
            this.container.find('.quizify-start-screen').hide();
            this.showQuestion(0);
            
            // Start the timer if time limit is set
            if (this.quizData && this.quizData.time_limit > 0) {
                this.timerSeconds = this.quizData.time_limit * 60;
                this.startTimer();
            }
            
            // Track quiz start with analytics
            if (window.quizifyAnalytics) {
                window.quizifyAnalytics.trackStart(this.quizId);
            }
        }
        
        /**
         * Load quiz data from server
         */
        loadQuizData() {
            $.ajax({
                url: quizify_public.ajax_url,
                type: 'POST',
                data: {
                    action: 'quizify_get_quiz',
                    quiz_id: this.quizId,
                    nonce: quizify_public.nonce
                },
                success: this.handleQuizData.bind(this),
                error: () => {
                    this.showError(quizify_public.strings.error);
                }
            });
        }
        
        /**
         * Handle quiz data received from server
         */
        handleQuizData(response) {
            if (!response.success) {
                this.showError(response.data.message || quizify_public.strings.error);
                return;
            }
            
            this.quizData = response.data;
            
            // Hide the loading indicator
            this.loading.hide();
            
            // Check if questions are available
            if (!this.quizData.questions || this.quizData.questions.length === 0) {
                this.showError('This quiz has no questions.');
                return;
            }
            
            // Render the start screen
            let startScreen = `
                <div class="quizify-start-screen">
                    <div class="quizify-description">${this.quizData.description || ''}</div>
                    <p class="quizify-info">
                        <span class="quizify-question-count">${this.quizData.questions.length} questions</span>
                        ${this.quizData.time_limit ? '<span class="quizify-time-limit">Time limit: ' + this.quizData.time_limit + ' minutes</span>' : ''}
                        <span class="quizify-pass-percent">Pass mark: ${this.quizData.passing_score}%</span>
                    </p>
                    <button class="quizify-start-button">Start Quiz</button>
                </div>
            `;
            
            this.content.html(startScreen).show();
        }
        
        /**
         * Show a specific question
         */
        showQuestion(index) {
            if (index < 0 || index >= this.quizData.questions.length) {
                return;
            }
            
            this.currentQuestion = index;
            const question = this.quizData.questions[index];
            
            // Save answers for the current question before showing the next one
            this.saveAnswers();
            
            let questionHtml = '';
            
            // Common question header
            questionHtml += `
                <div class="quizify-question" data-question-id="${question.id}" data-question-type="${question.type}">
                    <div class="quizify-question-header">
                        <h3 class="quizify-question-text">${question.text}</h3>
                        ${question.image_url ? '<div class="quizify-question-image"><img src="' + question.image_url + '" alt="Question image"></div>' : ''}
                    </div>
                    <div class="quizify-options">
            `;
            
            // Render options based on question type
            if (question.type === 'multiple') {
                // Multiple choice with multiple answers (checkboxes)
                questionHtml += '<div class="quizify-option-type-multiple">';
                question.options.forEach((option, i) => {
                    const checked = this.answers[question.id] && this.answers[question.id].indexOf(option.id) !== -1 ? 'checked' : '';
                    questionHtml += `
                        <div class="quizify-option">
                            <input type="checkbox" id="q${question.id}_o${option.id}" name="q${question.id}[]" value="${option.id}" ${checked}>
                            <label for="q${question.id}_o${option.id}">${option.text}</label>
                        </div>
                    `;
                });
                questionHtml += '</div>';
            } else if (question.type === 'single') {
                // Single choice with one answer (radio buttons)
                questionHtml += '<div class="quizify-option-type-single">';
                question.options.forEach((option, i) => {
                    const checked = this.answers[question.id] && this.answers[question.id][0] == option.id ? 'checked' : '';
                    questionHtml += `
                        <div class="quizify-option">
                            <input type="radio" id="q${question.id}_o${option.id}" name="q${question.id}" value="${option.id}" ${checked}>
                            <label for="q${question.id}_o${option.id}">${option.text}</label>
                        </div>
                    `;
                });
                questionHtml += '</div>';
            } else if (question.type === 'true_false') {
                // True/False with radio buttons
                questionHtml += '<div class="quizify-option-type-true-false">';
                question.options.forEach((option, i) => {
                    const checked = this.answers[question.id] && this.answers[question.id][0] == option.id ? 'checked' : '';
                    questionHtml += `
                        <div class="quizify-option">
                            <input type="radio" id="q${question.id}_o${option.id}" name="q${question.id}" value="${option.id}" ${checked}>
                            <label for="q${question.id}_o${option.id}">${option.text}</label>
                        </div>
                    `;
                });
                questionHtml += '</div>';
            } else if (question.type === 'text') {
                // Text input for short answers
                const value = this.answers[question.id] ? this.answers[question.id] : '';
                questionHtml += `
                    <div class="quizify-option-type-text">
                        <input type="text" id="q${question.id}_text" name="q${question.id}" 
                            value="${value}" placeholder="Your answer" class="quizify-text-input">
                    </div>
                `;
            } else if (question.type === 'paragraph') {
                // Textarea for long answers
                const value = this.answers[question.id] ? this.answers[question.id] : '';
                questionHtml += `
                    <div class="quizify-option-type-paragraph">
                        <textarea id="q${question.id}_text" name="q${question.id}" 
                            placeholder="Your answer" class="quizify-paragraph-input" rows="5">${value}</textarea>
                    </div>
                `;
            } else if (question.type === 'fill_blanks') {
                // Fill in the blanks question
                // The text includes [blank] placeholders that will be replaced with input fields
                
                if (question.correct_answer) {
                    let textWithInputs = question.correct_answer;
                    let blankCount = 0;
                    let savedAnswers = this.answers[question.id] || [];
                    
                    // Replace [blank] with input fields
                    textWithInputs = textWithInputs.replace(/\[blank\]/g, (match) => {
                        const value = savedAnswers[blankCount] || '';
                        const inputHtml = `<input type="text" id="q${question.id}_blank_${blankCount}" 
                                        name="q${question.id}_blank_${blankCount}" 
                                        class="quizify-fill-blanks-input" value="${value}"
                                        data-blank-index="${blankCount}">`;
                        blankCount++;
                        return inputHtml;
                    });
                    
                    questionHtml += `
                        <div class="quizify-option-type-fill-blanks">
                            <div class="quizify-fill-blanks-container" data-blanks-count="${blankCount}">
                                ${textWithInputs}
                            </div>
                        </div>
                    `;
                } else {
                    questionHtml += `<div class="quizify-error">Error: This question is not configured correctly.</div>`;
                }
            } else if (question.type === 'matching') {
                // Matching pairs with drag and drop
                questionHtml += `
                    <div class="quizify-option-type-matching">
                        <div class="quizify-matching-instructions">
                            Match each item on the left with its corresponding pair on the right.
                        </div>
                        <div class="quizify-matching-container">
                            <div class="quizify-matching-left">
                `;
                
                // Left column - terms
                question.options.forEach((option, i) => {
                    questionHtml += `
                        <div class="quizify-matching-term" data-id="${option.id}">
                            ${option.text}
                        </div>
                    `;
                });
                
                questionHtml += `
                            </div>
                            <div class="quizify-matching-right">
                `;
                
                // Right column - matches (shuffled)
                const shuffledOptions = [...question.options].sort(() => Math.random() - 0.5);
                shuffledOptions.forEach((option, i) => {
                    questionHtml += `
                        <div class="quizify-matching-match" data-id="${option.id}">
                            ${option.match}
                            <input type="hidden" id="q${question.id}_match_${option.id}" name="q${question.id}[${option.id}]" value="">
                        </div>
                    `;
                });
                
                questionHtml += `
                            </div>
                        </div>
                    </div>
                `;
            }
            
            // Close options div
            questionHtml += '</div>';
            
            // Add explanation box (initially hidden)
            if (question.explanation && question.explanation.trim() !== '') {
                questionHtml += `
                    <div class="quizify-explanation-box" id="explanation-${question.id}">
                        <div class="quizify-explanation-title">Explanation:</div>
                        <div class="quizify-explanation-content">${question.explanation}</div>
                    </div>
                `;
            }
            
            // Navigation buttons
            questionHtml += `
                <div class="quizify-navigation">
                    <button class="quizify-prev-button" ${index === 0 ? 'disabled' : ''}>Previous</button>
                    <span class="quizify-question-counter">${index + 1} of ${this.quizData.questions.length}</span>
                    ${index === this.quizData.questions.length - 1 
                        ? '<button class="quizify-submit-button">Submit Quiz</button>' 
                        : '<button class="quizify-next-button">Next</button>'}
                </div>
            `;
            
            // Progress bar
            questionHtml += `
                <div class="quizify-progress-container">
                    <div class="quizify-progress-bar" style="width: ${Math.round((index + 1) / this.quizData.questions.length * 100)}%"></div>
                </div>
            `;
            
            // Timer display (if time limit is set)
            if (this.quizData.time_limit > 0) {
                questionHtml += `
                    <div class="quizify-timer">Time remaining: <span class="quizify-timer-display">00:00</span></div>
                `;
            }
            
            // Close question div
            questionHtml += '</div>';
            
            this.content.html(questionHtml).show();
            
            // Update timer display
            if (this.quizData.time_limit > 0) {
                this.updateTimerDisplay();
            }
            
            // Initialize matching question type if present
            if (question.type === 'matching') {
                this.initMatchingQuestion();
            }
        }
        
        /**
         * Navigate between questions
         */
        navigate(e, direction) {
            e.preventDefault();
            
            if (direction === 'next') {
                if (this.currentQuestion < this.quizData.questions.length - 1) {
                    this.showQuestion(this.currentQuestion + 1);
                }
            } else if (direction === 'prev') {
                if (this.currentQuestion > 0) {
                    this.showQuestion(this.currentQuestion - 1);
                }
            }
        }
        
        /**
         * Show explanation for the current question
         */
        showExplanation(questionId) {
            const explanationBox = this.content.find(`#explanation-${questionId}`);
            if (explanationBox.length) {
                explanationBox.addClass('visible');
            }
        }
        
        /**
         * Save answers for the current question
         */
        saveAnswers() {
            const currentQuestionElement = this.content.find('.quizify-question');
            if (!currentQuestionElement.length) return;
            
            const questionId = currentQuestionElement.data('question-id');
            const questionType = currentQuestionElement.data('question-type');
            
            if (questionType === 'multiple') {
                // Multiple choice (checkboxes)
                const selectedOptions = [];
                currentQuestionElement.find('input[type="checkbox"]:checked').each(function() {
                    selectedOptions.push(parseInt($(this).val()));
                });
                this.answers[questionId] = selectedOptions;
            } else if (questionType === 'single' || questionType === 'true_false') {
                // Single choice or True/False (radio buttons)
                const selectedOption = currentQuestionElement.find('input[type="radio"]:checked').val();
                if (selectedOption) {
                    this.answers[questionId] = [parseInt(selectedOption)];
                }
            } else if (questionType === 'text' || questionType === 'paragraph') {
                // Text input or paragraph
                const textValue = currentQuestionElement.find('input[type="text"], textarea').val();
                if (textValue) {
                    this.answers[questionId] = textValue;
                }
            } else if (questionType === 'fill_blanks') {
                // Fill in the blanks
                const blankAnswers = [];
                const blankCount = currentQuestionElement.find('.quizify-fill-blanks-container').data('blanks-count');
                
                for (let i = 0; i < blankCount; i++) {
                    const blankInput = currentQuestionElement.find(`input[data-blank-index="${i}"]`);
                    if (blankInput.length) {
                        blankAnswers.push(blankInput.val());
                    } else {
                        blankAnswers.push('');
                    }
                }
                
                // Only save if there are answers
                if (blankAnswers.length > 0) {
                    this.answers[questionId] = blankAnswers;
                }
            } else if (questionType === 'matching') {
                // Matching pairs
                const matchingAnswers = {};
                currentQuestionElement.find('.quizify-matching-match').each(function() {
                    const matchId = $(this).data('id');
                    const termId = $(this).attr('data-matched-term');
                    
                    if (termId) {
                        matchingAnswers[termId] = matchId;
                    }
                });
                
                // Only save if there are answers
                if (Object.keys(matchingAnswers).length > 0) {
                    this.answers[questionId] = matchingAnswers;
                }
            }
        }
        
        /**
         * Update the question counter
         */
        updateQuestionCounter() {
            const counter = `${this.currentQuestion + 1} of ${this.quizData.questions.length}`;
            this.container.find('.quizify-question-counter').text(counter);
        }
        
        /**
         * Update the progress bar
         */
        updateProgressBar() {
            const percentage = Math.round((this.currentQuestion + 1) / this.quizData.questions.length * 100);
            this.container.find('.quizify-progress-bar').css('width', percentage + '%');
        }
        
        /**
         * Start the quiz timer
         */
        startTimer() {
            // Clear any existing timer
            if (this.timer) {
                clearInterval(this.timer);
            }
            
            // Update timer every second
            this.timer = setInterval(() => {
                this.timerSeconds--;
                this.updateTimerDisplay();
                
                // Auto-submit when time is up
                if (this.timerSeconds <= 0) {
                    clearInterval(this.timer);
                    alert(quizify_public.strings.time_up);
                    this.submitQuiz(null, true);
                }
            }, 1000);
        }
        
        /**
         * Update the timer display
         */
        updateTimerDisplay() {
            if (this.timerSeconds <= 0) {
                return;
            }
            
            const timerDisplay = this.formatTime(this.timerSeconds);
            this.container.find('.quizify-timer-display').text(timerDisplay);
        }
        
        /**
         * Format time in minutes and seconds
         */
        formatTime(seconds) {
            const minutes = Math.floor(seconds / 60);
            const secs = seconds % 60;
            return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        }
        
        /**
         * Submit the quiz
         */
        submitQuiz(e, timeUp = false) {
            if (e) {
                e.preventDefault();
            }
            
            // Save answers for the last question
            this.saveAnswers();
            
            // Confirm submission unless time is up
            if (!timeUp && !confirm(quizify_public.strings.submit_confirm)) {
                return;
            }
            
            // Show loading
            this.content.hide();
            this.loading.show();
            
            // Stop timer if active
            if (this.timer) {
                clearInterval(this.timer);
                this.timer = null;
            }
            
            // Submit answers to server
            $.ajax({
                url: quizify_public.ajax_url,
                type: 'POST',
                data: {
                    action: 'quizify_submit_quiz',
                    quiz_id: this.quizId,
                    answers: JSON.stringify(this.answers),
                    nonce: quizify_public.nonce
                },
                success: this.handleSubmissionResults.bind(this),
                error: () => {
                    this.loading.hide();
                    this.showError(quizify_public.strings.error);
                }
            });
            
            // Track quiz completion with analytics
            if (window.quizifyAnalytics) {
                window.quizifyAnalytics.prepareTrackCompletion(this.quizId);
            }
        }
        
        /**
         * Handle submission results
         */
        handleSubmissionResults(response) {
            // Hide loading
            this.loading.hide();
            
            if (!response.success) {
                this.showError(response.data.message || quizify_public.strings.error);
                return;
            }
            
            const results = response.data;
            
            // Track completion with analytics
            if (window.quizifyAnalytics) {
                window.quizifyAnalytics.trackCompletion(this.quizId, results.score, results.passed);
            }
            
            // Show results
            this.showResults(results);
        }
        
        /**
         * Show quiz results
         */
        showResults(results) {
            // Determine the message based on pass/fail
            const statusMessage = results.passed ? 
                (results.pass_message || 'Congratulations! You passed the quiz.') : 
                (results.fail_message || 'Sorry, you did not pass the quiz. Try again.');
                
            const statusClass = results.passed ? 'passed' : 'failed';
            
            // Show celebration animation if passed
            if (results.passed) {
                this.triggerCelebration();
            }
            
            // Build results HTML
            let resultsHtml = `
                <div class="quizify-results-header">
                    <h2 class="quizify-results-title">Quiz Results</h2>
                </div>
                <div class="quizify-results-summary">
                    <div class="quizify-results-score">
                        <span class="quizify-score-label">Your Score:</span> ${results.score}%
                    </div>
                    <div class="quizify-results-score">
                        <span class="quizify-score-label">Passing Score:</span> ${results.passing_score}%
                    </div>
                    <div class="quizify-results-status ${statusClass}">
                        ${statusMessage}
                    </div>
                </div>
            `;
            
            // Add detailed results if available
            if (results.questions) {
                resultsHtml += `
                    <div class="quizify-detailed-results">
                        <h3>Question Results</h3>
                `;
                
                results.questions.forEach((question) => {
                    const questionClass = question.correct ? 'correct' : 'incorrect';
                    const statusText = question.correct ? 'Correct' : 'Incorrect';
                    
                    resultsHtml += `
                        <div class="quizify-result-item ${questionClass}">
                            <div class="quizify-result-question">${question.text}</div>
                            <div class="quizify-result-status">${statusText}</div>
                            <div class="quizify-result-details">
                                <div class="quizify-result-your-answer">
                                    <span class="quizify-result-label">Your answer:</span>
                                    ${this.formatAnswerText(question.user_answer, question.id)}
                                </div>
                                <div class="quizify-result-correct-answer">
                                    <span class="quizify-result-label">Correct answer:</span>
                                    ${this.formatAnswerText(question.correct_answer, question.id)}
                                </div>
                                ${question.explanation ? `
                                <div class="quizify-result-explanation">
                                    <span class="quizify-result-label">Explanation:</span>
                                    <div class="quizify-explanation-content">${question.explanation}</div>
                                </div>
                                ` : ''}
                            </div>
                        </div>
                    `;
                });
                
                resultsHtml += '</div>';
            }
            
            // Add retake button
            resultsHtml += `
                <div class="quizify-results-actions">
                    <button class="quizify-retake-button">Retake Quiz</button>
                </div>
            `;
            
            // Show results
            this.results.html(resultsHtml).show();
        }
        
        /**
         * Format answer text from index numbers to option text
         */
        formatAnswerText(answerData, questionId) {
            // If no answer is provided
            if (!answerData || (Array.isArray(answerData) && answerData.length === 0) || 
                (typeof answerData === 'object' && Object.keys(answerData).length === 0)) {
                return 'No answer provided';
            }
            
            // Find the question
            let question = null;
            for (const q of this.quizData.questions) {
                if (q.id === questionId) {
                    question = q;
                    break;
                }
            }
            
            if (!question) {
                // Handle case when question is not found
                if (Array.isArray(answerData)) {
                    return answerData.join(', ');
                } else if (typeof answerData === 'object') {
                    return JSON.stringify(answerData);
                } else {
                    return String(answerData);
                }
            }
            
            // Format based on question type
            switch (question.type) {
                case 'multiple':
                    // Multiple choice - show all selected options
                    if (!Array.isArray(answerData)) return String(answerData);
                    
                    const answerTexts = [];
                    for (const index of answerData) {
                        for (const option of question.options) {
                            if (option.id === index) {
                                answerTexts.push(option.text);
                                break;
                            }
                        }
                    }
                    return answerTexts.join(', ') || 'No answer provided';
                    
                case 'single':
                case 'true_false':
                    // Single choice or True/False - show the selected option
                    if (!Array.isArray(answerData) || !answerData.length) return String(answerData);
                    
                    const index = answerData[0];
                    for (const option of question.options) {
                        if (option.id === index) {
                            return option.text;
                        }
                    }
                    return 'No answer provided';
                    
                case 'text':
                case 'paragraph':
                    // For text/paragraph, just return the text
                    return String(answerData);
                
                case 'fill_blanks':
                    // For fill in the blanks, show all the entered values
                    if (!Array.isArray(answerData)) return String(answerData);
                    
                    // Return a formatted version showing each blank value
                    return answerData.length > 0 
                        ? answerData.map((val, idx) => `Blank ${idx + 1}: ${val || '(empty)'}`).join('<br>')
                        : 'No answer provided';
                    
                case 'matching':
                    // For matching, show which terms were matched with which items
                    if (typeof answerData !== 'object') return String(answerData);
                    
                    const matchingTexts = [];
                    // For each term (key) show what it was matched with (value)
                    for (const termId in answerData) {
                        const matchId = answerData[termId];
                        let termText = termId;
                        let matchText = matchId;
                        
                        // Find the text for these IDs if possible
                        for (const option of question.options) {
                            if (option.id === parseInt(termId)) {
                                termText = option.text;
                            }
                            if (option.id === parseInt(matchId)) {
                                matchText = option.match;
                            }
                        }
                        
                        matchingTexts.push(`${termText} → ${matchText}`);
                    }
                    
                    return matchingTexts.join('<br>') || 'No matches provided';
                    
                default:
                    // For any other type, convert to string
                    if (Array.isArray(answerData)) {
                        return answerData.join(', ');
                    } else if (typeof answerData === 'object') {
                        return JSON.stringify(answerData);
                    } else {
                        return String(answerData);
                    }
            }
        }
        
        /**
         * Trigger celebration animation
         */
        triggerCelebration() {
            const confettiCount = 100;
            const colors = ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4caf50', '#8bc34a', '#cddc39', '#ffeb3b', '#ffc107', '#ff9800', '#ff5722'];
            
            // Create confetti container
            const confettiContainer = $('<div class="quizify-confetti-container"></div>');
            confettiContainer.css({
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                overflow: 'hidden',
                pointerEvents: 'none',
                zIndex: 1000
            });
            
            this.container.css('position', 'relative').append(confettiContainer);
            
            // Create confetti pieces
            for (let i = 0; i < confettiCount; i++) {
                setTimeout(() => {
                    const confetti = $('<div class="quizify-confetti"></div>');
                    const color = colors[Math.floor(Math.random() * colors.length)];
                    const left = Math.random() * 100;
                    const delay = Math.random() * 2;
                    
                    confetti.css({
                        '--color': color,
                        left: left + '%',
                        top: '-10px',
                        animationDelay: delay + 's'
                    });
                    
                    confettiContainer.append(confetti);
                    
                    // Remove confetti after animation
                    setTimeout(() => {
                        confetti.remove();
                    }, 3000);
                }, Math.random() * 500);
            }
            
            // Remove container after all confetti are gone
            setTimeout(() => {
                confettiContainer.remove();
            }, 3500);
        }
        
        /**
         * Show error message
         */
        showError(message) {
            this.loading.hide();
            this.content.html(`<p class="quizify-error">${message}</p>`).show();
        }
        
        /**
         * Initialize matching question type
         */
        initMatchingQuestion() {
            const $question = this.content.find('.quizify-question');
            const questionId = $question.data('question-id');
            let selectedTerm = null;
            
            // Handle term selection
            $question.find('.quizify-matching-term').on('click', function() {
                const $this = $(this);
                const termId = $this.data('id');
                
                // Deselect any previously selected term
                $question.find('.quizify-matching-term').removeClass('selected');
                
                // Select this term
                $this.addClass('selected');
                selectedTerm = termId;
            });
            
            // Handle match selection
            $question.find('.quizify-matching-match').on('click', function() {
                const $this = $(this);
                const matchId = $this.data('id');
                
                // If no term is selected, do nothing
                if (selectedTerm === null) {
                    return;
                }
                
                // Remove any previous matching for this term and match
                $question.find('.quizify-matching-term').each(function() {
                    if ($(this).attr('data-matched-match') == matchId) {
                        $(this).removeAttr('data-matched-match').removeClass('matched');
                    }
                });
                
                $question.find('.quizify-matching-match').each(function() {
                    if ($(this).attr('data-matched-term') == selectedTerm) {
                        $(this).removeAttr('data-matched-term').removeClass('matched');
                    }
                });
                
                // Get the term element
                const $term = $question.find(`.quizify-matching-term[data-id="${selectedTerm}"]`);
                
                // Match them
                $term.attr('data-matched-match', matchId).addClass('matched');
                $this.attr('data-matched-term', selectedTerm).addClass('matched');
                
                // Update hidden input fields for this match
                $question.find(`input[name="q${questionId}[${selectedTerm}]"]`).val(matchId);
                
                // Reset selection
                selectedTerm = null;
                $question.find('.quizify-matching-term').removeClass('selected');
            });
        }
        
        /**
         * Retake the quiz
         */
        retakeQuiz(e) {
            e.preventDefault();
            
            // Reset quiz state
            this.currentQuestion = 0;
            this.answers = {};
            this.results.hide();
            
            // Show the start screen again
            this.loadQuizData();
        }
    }
    
    // Make QuizPlayer available globally
    window.QuizPlayer = QuizPlayer;
    
    // Initialize quizzes when page loads
    $(document).ready(function() {
        $('.quizify-container').each(function() {
            new QuizPlayer($(this));
        });
    });
    
})(jQuery);