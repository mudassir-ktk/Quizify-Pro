/**
 * Quizify Analytics JavaScript
 * 
 * Handles quiz usage analytics on the front-end, including search tracking
 */
(function($) {
    'use strict';
    
    /**
     * Initialize analytics when document is ready
     */
    $(document).ready(function() {
        if (typeof quizify_public !== 'undefined') {
            // Only initialize if we're on a page with Quizify
            window.quizifyAnalytics = new QuizifyAnalytics();
        }
    });
    
    /**
     * Analytics class for tracking quiz usage
     */
    class QuizifyAnalytics {
        /**
         * Initialize analytics
         */
        constructor() {
            this.data = {
                url: window.location.href,
                referrer: document.referrer,
                userAgent: navigator.userAgent,
                screenSize: {
                    width: window.innerWidth,
                    height: window.innerHeight
                },
                timeSpent: 0,
                searchQuery: this.extractSearchQuery()
            };
            
            // Start tracking time spent
            this.startTimeTracking();
            
            // Track when user leaves the page
            $(window).on('beforeunload', this.trackPageExit.bind(this));
            
            console.log('Quizify Analytics initialized');
        }
        
        /**
         * Start tracking time spent on page
         */
        startTimeTracking() {
            this.startTime = new Date();
            this.trackingInterval = setInterval(() => {
                this.data.timeSpent = Math.round((new Date() - this.startTime) / 1000);
            }, 1000);
        }
        
        /**
         * Track when a quiz is started
         */
        trackStart(quizId) {
            if (!quizId) return;
            
            console.log('Quiz started:', quizId);
            this.currentQuizId = quizId;
            this.quizStartTime = new Date();
            
            // Send data to server via AJAX
            $.ajax({
                url: quizify_public.ajax_url,
                type: 'POST',
                data: {
                    action: 'quizify_track_start',
                    nonce: quizify_public.nonce,
                    quiz_id: quizId
                },
                success: (response) => {
                    if (response.success) {
                        this.attemptId = response.data.attempt_id;
                        console.log('Start tracking successful. Attempt ID:', this.attemptId);
                    }
                }
            });
        }
        
        /**
         * Extract search query from URL
         * This checks for common search engine parameters like 'q', 'query', 'search', etc.
         */
        extractSearchQuery() {
            try {
                const url = new URL(this.data?.referrer || window.location.href);
                const params = new URLSearchParams(url.search);
                
                // Check common search query parameters
                const searchParams = ['q', 'query', 'search', 'term', 'p', 's', 'keyword'];
                
                for (const param of searchParams) {
                    if (params.has(param)) {
                        return params.get(param);
                    }
                }
                
                // Also check for hash parameters
                if (url.hash && url.hash.includes('=')) {
                    const hashParams = new URLSearchParams(url.hash.substring(1));
                    for (const param of searchParams) {
                        if (hashParams.has(param)) {
                            return hashParams.get(param);
                        }
                    }
                }
                
                return '';
            } catch (error) {
                console.error('Error extracting search query:', error);
                return '';
            }
        }
        
        /**
         * Track when a quiz is completed
         */
        trackCompletion(quizId, score, passed) {
            if (!quizId) return;
            
            clearInterval(this.trackingInterval);
            
            const timeSpent = this.currentQuizId === quizId && this.quizStartTime 
                ? Math.round((new Date() - this.quizStartTime) / 1000) 
                : 0;
            
            // Extract keywords from URL or search queries
            const keywords = this.extractKeywords();
            
            // Send data to server via AJAX
            $.ajax({
                url: quizify_public.ajax_url,
                type: 'POST',
                data: {
                    action: 'quizify_track_completion',
                    nonce: quizify_public.nonce,
                    quiz_id: quizId,
                    attempt_id: this.attemptId || 0,
                    score: score,
                    passed: passed ? 1 : 0,
                    time_spent: timeSpent,
                    traffic_source: this.data.referrer || '',
                    referrer: this.data.referrer || '',
                    location: '',  // Could use geolocation API if needed
                    keywords: keywords,
                    search_query: this.data.searchQuery || ''
                },
                success: (response) => {
                    if (response.success) {
                        console.log('Completion tracking successful. Attempt ID:', response.data.attempt_id);
                    }
                }
            });
        }
        
        /**
         * Extract keywords from URL or search query
         */
        extractKeywords() {
            // If we have a search query, use that as keywords
            if (this.data.searchQuery) {
                return this.data.searchQuery;
            }
            
            // Try to extract keywords from the URL
            try {
                const url = new URL(window.location.href);
                const path = url.pathname;
                
                // Remove common file extensions and split by common separators
                const cleanPath = path.replace(/\.(html|php|aspx?)$/i, '');
                const segments = cleanPath.split(/[\/\-_]/);
                
                // Filter out empty segments and common words
                const keywords = segments.filter(segment => {
                    return segment.length > 2 && !/^(and|the|or|of|in|on|at|to|a|an)$/i.test(segment);
                });
                
                return keywords.join(', ');
            } catch (error) {
                console.error('Error extracting keywords:', error);
                return '';
            }
        }
        
        /**
         * Track user exiting the page
         */
        trackPageExit() {
            clearInterval(this.trackingInterval);
            
            if (!this.currentQuizId || !this.attemptId) {
                return;
            }
            
            // Use sendBeacon API as it's more reliable for beforeunload events
            if (navigator.sendBeacon) {
                const formData = new FormData();
                formData.append('action', 'quizify_track_exit');
                formData.append('nonce', quizify_public.nonce);
                formData.append('quiz_id', this.currentQuizId);
                formData.append('attempt_id', this.attemptId);
                formData.append('time_spent', this.data.timeSpent);
                
                navigator.sendBeacon(quizify_public.ajax_url, formData);
                console.log('Page exit tracked via beacon');
            } else {
                // Fallback to synchronous AJAX (less reliable)
                $.ajax({
                    url: quizify_public.ajax_url,
                    type: 'POST',
                    async: false,
                    data: {
                        action: 'quizify_track_exit',
                        nonce: quizify_public.nonce,
                        quiz_id: this.currentQuizId,
                        attempt_id: this.attemptId,
                        time_spent: this.data.timeSpent
                    }
                });
                console.log('Page exit tracked via AJAX');
            }
        }
    }
    
    // Make the QuizifyAnalytics class available globally
    window.QuizifyAnalytics = QuizifyAnalytics;
    
})(jQuery);