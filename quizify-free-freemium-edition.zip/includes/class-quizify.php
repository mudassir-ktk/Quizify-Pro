<?php
/**
 * The core plugin class.
 *
 * @since      1.0.0
 *
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/includes
 */

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * The core plugin class.
 *
 * This is used to define admin-specific hooks, internationalization,
 * and public-facing site hooks.
 *
 * @since      1.0.0
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/includes
 * @author     NetworkUstad Team
 */
class Quizify {

    /**
     * The loader that's responsible for maintaining and registering all hooks that power
     * the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      Quizify_Loader    $loader    Maintains and registers all hooks for the plugin.
     */
    protected $loader;

    /**
     * Define the core functionality of the plugin.
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Load dependencies
        $this->load_dependencies();
        
        // Define admin hooks
        $this->define_admin_hooks();
        
        // Define public hooks
        $this->define_public_hooks();
    }

    /**
     * Load the required dependencies for this plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function load_dependencies() {
        // The class responsible for orchestrating the actions and filters
        require_once QUIZIFY_PRO_PLUGIN_DIR . 'includes/class-quizify-loader.php';
        
        // The class responsible for defining all actions in the admin area
        require_once QUIZIFY_PRO_PLUGIN_DIR . 'admin/class-quizify-admin.php';
        
        // The class responsible for defining all actions in the public-facing side
        require_once QUIZIFY_PRO_PLUGIN_DIR . 'public/class-quizify-public.php';
        
        // The class responsible for handling license verification
        require_once QUIZIFY_PRO_PLUGIN_DIR . 'includes/class-quizify-license.php';
        
        // The class responsible for feature management
        require_once QUIZIFY_PRO_PLUGIN_DIR . 'includes/class-quizify-features.php';
        
        // The class responsible for quiz functionality
        require_once QUIZIFY_PRO_PLUGIN_DIR . 'includes/class-quizify-quiz.php';
        
        // The class responsible for analytics functionality
        require_once QUIZIFY_PRO_PLUGIN_DIR . 'includes/class-quizify-analytics.php';
        
        $this->loader = new Quizify_Loader();
    }

    /**
     * Register all of the hooks related to the admin area functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_admin_hooks() {
        $admin = new Quizify_Admin();
        $license = new Quizify_License();
        $analytics = new Quizify_Analytics();
        
        // Admin assets
        $this->loader->add_action('admin_enqueue_scripts', $admin, 'enqueue_styles');
        $this->loader->add_action('admin_enqueue_scripts', $admin, 'enqueue_scripts');
        
        // Register post type and meta boxes
        $this->loader->add_action('init', $admin, 'register_post_type');
        $this->loader->add_action('add_meta_boxes', $admin, 'add_meta_boxes');
        $this->loader->add_action('save_post_quizify_quiz', $admin, 'save_quiz_meta', 10, 2);
        
        // Admin menu
        $this->loader->add_action('admin_menu', $admin, 'add_admin_menu');
        
        // Admin AJAX handlers
        $this->loader->add_action('wp_ajax_quizify_save_quiz', $admin, 'ajax_save_quiz');
        
        // Analytics page
        $this->loader->add_action('admin_menu', $analytics, 'add_analytics_page');
        $this->loader->add_action('wp_ajax_quizify_get_analytics_data', $analytics, 'ajax_get_analytics_data');
        $this->loader->add_action('wp_ajax_quizify_search_analytics', $analytics, 'ajax_search_analytics');
        
        // License management
        $this->loader->add_action('admin_init', $license, 'check_license');
    }

    /**
     * Register all of the hooks related to the public-facing functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_public_hooks() {
        $public = new Quizify_Public();
        $analytics = new Quizify_Analytics();
        
        // Public assets
        $this->loader->add_action('wp_enqueue_scripts', $public, 'enqueue_styles');
        $this->loader->add_action('wp_enqueue_scripts', $public, 'enqueue_scripts');
        
        // Register shortcodes
        $this->loader->add_action('init', $public, 'register_shortcodes');
        
        // Public AJAX handlers
        $this->loader->add_action('wp_ajax_quizify_get_quiz', $public, 'ajax_get_quiz');
        $this->loader->add_action('wp_ajax_nopriv_quizify_get_quiz', $public, 'ajax_get_quiz');
        
        $this->loader->add_action('wp_ajax_quizify_submit_quiz', $public, 'ajax_submit_quiz');
        $this->loader->add_action('wp_ajax_nopriv_quizify_submit_quiz', $public, 'ajax_submit_quiz');
        
        // Analytics tracking
        $this->loader->add_action('wp_ajax_quizify_track_start', $analytics, 'ajax_track_start');
        $this->loader->add_action('wp_ajax_nopriv_quizify_track_start', $analytics, 'ajax_track_start');
        
        $this->loader->add_action('wp_ajax_quizify_track_completion', $analytics, 'ajax_track_completion');
        $this->loader->add_action('wp_ajax_nopriv_quizify_track_completion', $analytics, 'ajax_track_completion');
        
        $this->loader->add_action('wp_ajax_quizify_track_exit', $analytics, 'ajax_track_exit');
        $this->loader->add_action('wp_ajax_nopriv_quizify_track_exit', $analytics, 'ajax_track_exit');
    }

    /**
     * Run the loader to execute all of the hooks with WordPress.
     *
     * @since    1.0.0
     */
    public function run() {
        $this->loader->run();
    }
}