<?php
/**
 * Quizify License Class
 *
 * Handles license key verification and activation
 *
 * @link       https://networkustad.com
 * @since      1.0.0
 *
 * @package    Quizify
 * @subpackage Quizify/includes
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) exit;

/**
 * The license functionality of the plugin.
 *
 * Defines the license management and activation functionality
 *
 * @package    Quizify
 * @subpackage Quizify/includes
 * @author     NetworkUstad Team <support@networkustad.com>
 */
class Quizify_License {

    /**
     * License API URL
     * 
     * @var string
     */
    private $api_url = 'https://networkustad.com/api/license/';
    
    /**
     * Test license keys for development mode
     * Used only when QUIZIFY_DEV_MODE is true
     * 
     * @var array
     */
    private $test_keys = array(
        'PERSONAL-1234-5678-ABCD-EFGH', // Personal license - 1 site
        'PERSONAL-5678-1234-ABCD-XYZW', // Personal license - 1 site
        'PERSONAL-ABCD-EFGH-1234-5678', // Personal license - 1 site
        'PLUS-1234-5678-ABCD-EFGH',     // Plus license - 3 sites
        'PLUS-5678-1234-ABCD-XYZW',     // Plus license - 3 sites
        'PLUS-ABCD-EFGH-1234-5678',     // Plus license - 3 sites
        'PRO-1234-5678-ABCD-EFGH',      // Professional license - 5 sites
        'PRO-5678-1234-ABCD-XYZW',      // Professional license - 5 sites
        'PRO-ABCD-EFGH-1234-5678',      // Professional license - 5 sites
    );
    
    /**
     * Initialize the license management
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Add hooks for license management
        add_action('admin_menu', array($this, 'add_license_menu'));
        add_action('admin_init', array($this, 'process_license_activation'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_license_scripts'));
    }
    
    /**
     * Add license menu page
     */
    public function add_license_menu() {
        // Add submenu page for license activation
        add_submenu_page(
            'quizify_admin',                        // Parent menu slug
            'Quizify License',                      // Page title
            Quizify_Features::is_pro() ? 'License' : 'Upgrade to Pro', // Menu title
            'manage_options',                       // Capability
            'quizify_license',                      // Menu slug
            array($this, 'render_license_page')     // Callback
        );
    }
    
    /**
     * Enqueue license page scripts and styles
     */
    public function enqueue_license_scripts($hook) {
        // Only on license page
        if ($hook !== 'quizify_license') {
            return;
        }
        
        // Add inline styles
        wp_add_inline_style('wp-admin', '
            .quizify-license-page {
                max-width: 800px;
                margin: 20px auto;
            }
            .quizify-license-form {
                background: #fff;
                border-radius: 5px;
                padding: 25px;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                margin-top: 20px;
            }
            .quizify-license-info {
                background: #f8f9fa;
                border-left: 4px solid #2271b1;
                padding: 15px;
                margin-bottom: 20px;
            }
            .quizify-license-heading {
                color: #2271b1;
                font-size: 24px;
                margin-top: 0;
            }
            .quizify-license-input {
                width: 100%;
                padding: 8px;
                font-size: 16px;
                margin-bottom: 10px;
            }
            .quizify-license-submit {
                background: #2271b1;
                color: #fff;
                border: none;
                padding: 10px 20px;
                font-size: 16px;
                cursor: pointer;
                border-radius: 3px;
            }
            .quizify-license-submit:hover {
                background: #135e96;
            }
            .quizify-license-error {
                color: #d63638;
                margin-top: 10px;
                padding: 10px;
                border-left: 4px solid #d63638;
                background: #f8d7da;
            }
            .quizify-license-success {
                color: #00a32a;
                margin-top: 10px;
                padding: 10px;
                border-left: 4px solid #00a32a;
                background: #d1e7dd;
            }
            .quizify-license-status {
                display: inline-block;
                padding: 5px 10px;
                border-radius: 3px;
                font-weight: bold;
                margin-left: 10px;
            }
            .quizify-license-status.active {
                background: #d1e7dd;
                color: #00a32a;
            }
            .quizify-license-status.inactive {
                background: #f8d7da;
                color: #d63638;
            }
            .quizify-pricing-table {
                display: flex;
                flex-wrap: wrap;
                justify-content: space-between;
                margin-top: 30px;
                gap: 20px;
            }
            .quizify-pricing-card {
                flex: 1;
                min-width: 250px;
                background: #fff;
                border-radius: 5px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                padding: 25px;
                text-align: center;
                border-top: 5px solid #2271b1;
                transition: transform 0.3s ease;
            }
            .quizify-pricing-card:hover {
                transform: translateY(-5px);
            }
            .quizify-pricing-card.highlighted {
                border-top-color: #ff6b6b;
                transform: scale(1.05);
            }
            .quizify-pricing-card.highlighted:hover {
                transform: scale(1.05) translateY(-5px);
            }
            .quizify-pricing-card h3 {
                margin-top: 0;
                font-size: 22px;
                color: #1d2327;
            }
            .quizify-pricing-price {
                font-size: 28px;
                font-weight: bold;
                margin: 20px 0;
                color: #2271b1;
            }
            .quizify-pricing-period {
                font-size: 16px;
                color: #646970;
            }
            .quizify-pricing-features {
                list-style: none;
                padding: 0;
                margin: 0 0 25px;
                text-align: left;
            }
            .quizify-pricing-features li {
                margin-bottom: 10px;
                position: relative;
                padding-left: 25px;
            }
            .quizify-pricing-features li:before {
                content: "✓";
                position: absolute;
                left: 0;
                color: #00a32a;
                font-weight: bold;
            }
            .quizify-pricing-action {
                display: inline-block;
                background: #2271b1;
                color: #fff;
                padding: 10px 20px;
                border-radius: 5px;
                text-decoration: none;
                font-weight: bold;
                transition: background 0.3s ease;
            }
            .quizify-pricing-action:hover {
                background: #135e96;
                color: #fff;
            }
            .quizify-payment-methods {
                margin-top: 40px;
                background: #fff;
                padding: 20px;
                border-radius: 5px;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            }
            .quizify-payment-methods h3 {
                margin-top: 0;
                border-bottom: 1px solid #ddd;
                padding-bottom: 10px;
            }
            .quizify-payment-logos {
                display: flex;
                flex-wrap: wrap;
                gap: 20px;
                align-items: center;
                margin-top: 20px;
                justify-content: center;
            }
            .quizify-payment-logo {
                display: inline-block;
                padding: 8px 15px;
                border: 1px solid #ddd;
                border-radius: 5px;
                background: #f8f9fa;
                color: #50575e;
                font-weight: 500;
                transition: all 0.3s ease;
            }
            .quizify-payment-logo:hover {
                border-color: #2271b1;
                background: #f0f0f1;
            }
        ');
    }
    
    /**
     * Render license page content
     */
    public function render_license_page() {
        $current_license = get_option('quizify_license_key', '');
        $license_status = get_option('quizify_license_status', '');
        $license_data = get_option('quizify_license_data', array());
        $is_pro = Quizify_Features::is_pro();
        
        // Check for license errors
        $error = isset($_GET['error']) ? sanitize_text_field($_GET['error']) : '';
        $success = isset($_GET['success']) ? '1' === $_GET['success'] : false;
        
        ?>
        <div class="wrap quizify-license-page">
            <h1 class="quizify-license-heading"><?php echo $is_pro ? 'Quizify Pro License' : 'Upgrade to Quizify Pro'; ?></h1>
            
            <?php if (!$is_pro) : ?>
                <!-- Show upgrade info for free version -->
                <div class="quizify-license-info">
                    <p>You are currently using the free version of Quizify. Upgrade to Quizify Pro to unlock all premium features!</p>
                </div>
                
                <!-- Pricing table -->
                <div class="quizify-pricing-table">
                    <!-- Personal plan -->
                    <div class="quizify-pricing-card">
                        <h3>Personal</h3>
                        <div class="quizify-pricing-price">$15<span class="quizify-pricing-period">/month</span></div>
                        <ul class="quizify-pricing-features">
                            <li>Single Site License</li>
                            <li>All Premium Question Types</li>
                            <li>Question Explanations</li>
                            <li>Unlimited Quizzes</li>
                            <li>Basic Analytics</li>
                        </ul>
                        <a href="#license-form" class="quizify-pricing-action">Activate Now</a>
                    </div>
                    
                    <!-- Plus plan (highlighted) -->
                    <div class="quizify-pricing-card highlighted">
                        <h3>Plus</h3>
                        <div class="quizify-pricing-price">$30<span class="quizify-pricing-period">/month</span></div>
                        <ul class="quizify-pricing-features">
                            <li>3 Site Licenses</li>
                            <li>All Premium Question Types</li>
                            <li>Question Explanations</li>
                            <li>Unlimited Quizzes</li>
                            <li>Advanced Analytics</li>
                            <li>Priority Support</li>
                            <li>CSV Export</li>
                        </ul>
                        <a href="#license-form" class="quizify-pricing-action">Activate Now</a>
                    </div>
                    
                    <!-- Professional plan -->
                    <div class="quizify-pricing-card">
                        <h3>Professional</h3>
                        <div class="quizify-pricing-price">$40<span class="quizify-pricing-period">/month</span></div>
                        <ul class="quizify-pricing-features">
                            <li>5 Site Licenses</li>
                            <li>All Premium Question Types</li>
                            <li>Question Explanations</li>
                            <li>Unlimited Quizzes</li>
                            <li>Advanced Analytics</li>
                            <li>Priority Support</li>
                            <li>CSV/Excel Export</li>
                            <li>API Access</li>
                        </ul>
                        <a href="#license-form" class="quizify-pricing-action">Activate Now</a>
                    </div>
                </div>
                
                <div class="quizify-license-info" style="margin-top: 20px;">
                    <p><strong>Save 50%</strong> with yearly plans! Contact us for more information.</p>
                </div>
                
                <!-- Payment methods -->
                <div class="quizify-payment-methods">
                    <h3>Payment Methods</h3>
                    <div class="quizify-payment-logos">
                        <span class="quizify-payment-logo">PayPal</span>
                        <span class="quizify-payment-logo">Payoneer</span>
                        <span class="quizify-payment-logo">NayaPay</span>
                        <span class="quizify-payment-logo">SadaPay</span>
                        <span class="quizify-payment-logo">UPaisa</span>
                        <span class="quizify-payment-logo">Credit Card</span>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- License form -->
            <div class="quizify-license-form" id="license-form">
                <h2><?php echo $is_pro ? 'Manage Your License' : 'Activate Your License Key'; ?></h2>
                
                <?php if ($is_pro) : ?>
                    <div class="quizify-license-info">
                        <p>Your Quizify Pro license is currently 
                            <span class="quizify-license-status <?php echo $license_status === 'valid' ? 'active' : 'inactive'; ?>">
                                <?php echo $license_status === 'valid' ? 'ACTIVE' : 'INACTIVE'; ?>
                            </span>
                        </p>
                        
                        <?php if (!empty($license_data)) : ?>
                            <p><strong>Plan:</strong> <?php echo isset($license_data['plan']) ? esc_html($license_data['plan']) : 'Unknown'; ?></p>
                            <p><strong>Expires:</strong> <?php echo isset($license_data['expires']) ? esc_html($license_data['expires']) : 'Unknown'; ?></p>
                            <p><strong>Sites:</strong> <?php echo isset($license_data['sites']) ? esc_html($license_data['sites']) : '1'; ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($error)) : ?>
                    <div class="quizify-license-error">
                        <?php echo esc_html($error); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success) : ?>
                    <div class="quizify-license-success">
                        License key activated successfully! Quizify Pro features are now unlocked.
                    </div>
                <?php endif; ?>
                
                <form method="post" action="<?php echo admin_url('admin.php?page=quizify_license'); ?>">
                    <?php wp_nonce_field('quizify_license_nonce', 'quizify_license_nonce'); ?>
                    
                    <p>
                        <input type="text" name="quizify_license_key" class="quizify-license-input" 
                               value="<?php echo esc_attr($current_license); ?>" 
                               placeholder="Enter your license key" />
                    </p>
                    
                    <?php if ($is_pro && $license_status === 'valid') : ?>
                        <input type="submit" name="quizify_license_deactivate" class="quizify-license-submit" 
                               value="Deactivate License" style="background: #d63638;" />
                    <?php else : ?>
                        <input type="submit" name="quizify_license_activate" class="quizify-license-submit" 
                               value="Activate License" />
                    <?php endif; ?>
                </form>
                
                <?php if (!$is_pro) : ?>
                    <p><small>Need a license key? <a href="https://networkustad.com/quizify-pro" target="_blank">Purchase Quizify Pro</a></small></p>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
    
    /**
     * Process license activation/deactivation
     */
    public function process_license_activation() {
        // Check for activation request
        if (isset($_POST['quizify_license_activate']) && isset($_POST['quizify_license_nonce'])) {
            // Verify nonce
            if (!wp_verify_nonce($_POST['quizify_license_nonce'], 'quizify_license_nonce')) {
                wp_die('Security check failed');
            }
            
            // Get license key
            $license_key = isset($_POST['quizify_license_key']) ? sanitize_text_field($_POST['quizify_license_key']) : '';
            
            // Validate license key format (basic check)
            if (empty($license_key) || strlen($license_key) < 10) {
                wp_redirect(admin_url('admin.php?page=quizify_license&error=Please+enter+a+valid+license+key'));
                exit;
            }
            
            // Store the license key
            update_option('quizify_license_key', $license_key);
            
            // Verify the license with the API
            $response = $this->verify_license($license_key);
            
            if ($response['success']) {
                // License is valid - store the status and data
                update_option('quizify_license_status', 'valid');
                update_option('quizify_license_data', $response['data']);
                
                // Mark as pro version and start the upgrade process
                update_option('quizify_is_pro', true);
                update_option('quizify_pro_upgrade_pending', true);
                
                // Redirect with success message
                wp_redirect(admin_url('admin.php?page=quizify_license&success=1'));
                exit;
            } else {
                // License is invalid - redirect with error
                wp_redirect(admin_url('admin.php?page=quizify_license&error=' . urlencode($response['message'])));
                exit;
            }
        }
        
        // Check for deactivation request
        if (isset($_POST['quizify_license_deactivate']) && isset($_POST['quizify_license_nonce'])) {
            // Verify nonce
            if (!wp_verify_nonce($_POST['quizify_license_nonce'], 'quizify_license_nonce')) {
                wp_die('Security check failed');
            }
            
            // Get current license key
            $license_key = get_option('quizify_license_key', '');
            
            // Deactivate the license with the API
            $response = $this->deactivate_license($license_key);
            
            if ($response['success']) {
                // License is deactivated - update the status
                update_option('quizify_license_status', 'inactive');
                delete_option('quizify_license_data');
                
                // Mark as free version (but don't downgrade yet)
                update_option('quizify_is_pro', false);
                
                // Redirect with success message
                wp_redirect(admin_url('admin.php?page=quizify_license&success=1'));
                exit;
            } else {
                // Deactivation failed - redirect with error
                wp_redirect(admin_url('admin.php?page=quizify_license&error=' . urlencode($response['message'])));
                exit;
            }
        }
    }
    
    /**
     * Verify license key with API
     *
     * @param string $license_key License key to verify
     * @return array Response with success status, message, and data
     */
    private function verify_license($license_key) {
        // Check if we're in development mode
        if (defined('QUIZIFY_DEV_MODE') && QUIZIFY_DEV_MODE) {
            // In dev mode, check against test keys
            if (in_array($license_key, $this->test_keys)) {
                // Extract the plan from the key prefix
                $plan = 'Personal';
                if (strpos($license_key, 'PLUS-') === 0) {
                    $plan = 'Plus';
                } elseif (strpos($license_key, 'PRO-') === 0) {
                    $plan = 'Professional';
                }
                
                // Set sites based on plan
                $sites = 1;
                if ($plan === 'Plus') {
                    $sites = 3;
                } elseif ($plan === 'Professional') {
                    $sites = 5;
                }
                
                // Return success with fake data
                return array(
                    'success' => true,
                    'message' => 'License verified successfully',
                    'data' => array(
                        'plan' => $plan,
                        'expires' => date('Y-m-d', strtotime('+1 year')),
                        'sites' => $sites,
                        'customer' => 'Test Customer',
                        'email' => 'test@example.com',
                    ),
                );
            } else {
                // Invalid test key
                return array(
                    'success' => false,
                    'message' => 'Invalid license key. Please try one of the test keys.',
                );
            }
        }
        
        // In production, make a real API call
        $api_url = $this->api_url . 'verify';
        $site_url = home_url();
        
        // Make API request
        $response = wp_remote_post($api_url, array(
            'body' => array(
                'license_key' => $license_key,
                'site_url' => $site_url,
            ),
        ));
        
        // Check for error
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'API connection error: ' . $response->get_error_message(),
            );
        }
        
        // Parse the response
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        // Check response format
        if (!isset($data['success'])) {
            return array(
                'success' => false,
                'message' => 'Invalid API response',
            );
        }
        
        // Return the response
        return $data;
    }
    
    /**
     * Deactivate license key with API
     *
     * @param string $license_key License key to deactivate
     * @return array Response with success status and message
     */
    private function deactivate_license($license_key) {
        // Check if we're in development mode
        if (defined('QUIZIFY_DEV_MODE') && QUIZIFY_DEV_MODE) {
            // In dev mode, always succeed
            return array(
                'success' => true,
                'message' => 'License deactivated successfully',
            );
        }
        
        // In production, make a real API call
        $api_url = $this->api_url . 'deactivate';
        $site_url = home_url();
        
        // Make API request
        $response = wp_remote_post($api_url, array(
            'body' => array(
                'license_key' => $license_key,
                'site_url' => $site_url,
            ),
        ));
        
        // Check for error
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'API connection error: ' . $response->get_error_message(),
            );
        }
        
        // Parse the response
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        // Check response format
        if (!isset($data['success'])) {
            return array(
                'success' => false,
                'message' => 'Invalid API response',
            );
        }
        
        // Return the response
        return $data;
    }
}