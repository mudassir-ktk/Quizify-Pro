<?php
/**
 * Fired during plugin deactivation
 *
 * @since      1.0.0
 *
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/includes
 */

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Quizify_Pro
 * @subpackage Quizify_Pro/includes
 * @author     NetworkUstad Team
 */
class Quizify_Deactivator {

    /**
     * Clean up plugin data when deactivating.
     *
     * @since    1.0.0
     */
    public static function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // We don't delete any data or tables here to preserve user data
        // Data cleanup should be handled during uninstall if needed
    }
}