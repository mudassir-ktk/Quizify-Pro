<?php
/**
 * Quizify Features Class
 *
 * Handles feature restrictions and premium feature management
 *
 * @link       https://networkustad.com
 * @since      1.0.0
 *
 * @package    Quizify
 * @subpackage Quizify/includes
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) exit;

/**
 * The features functionality of the plugin.
 *
 * Defines the premium features and handles restriction in the free version
 *
 * @package    Quizify
 * @subpackage Quizify/includes
 * @author     NetworkUstad Team <support@networkustad.com>
 */
class Quizify_Features {

    /**
     * Maximum number of quizzes in free version
     */
    const MAX_FREE_QUIZZES = 3;
    
    /**
     * Maximum number of questions per quiz in free version
     */
    const MAX_FREE_QUESTIONS = 5;
    
    /**
     * Maximum number of options per question in free version
     */
    const MAX_FREE_OPTIONS = 4;
    
    /**
     * Initialize the features
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Add hooks for feature restriction
        add_action('admin_enqueue_scripts', array($this, 'enqueue_feature_vars'));
        add_action('admin_notices', array($this, 'show_upgrade_notice'));
        add_filter('quizify_save_quiz', array($this, 'enforce_quiz_limits'), 10, 2);
        add_filter('quizify_available_question_types', array($this, 'restrict_question_types'));
        add_filter('quizify_admin_tabs', array($this, 'restrict_admin_tabs'), 10, 1);
        add_filter('quizify_max_quizzes', array($this, 'get_max_quizzes'));
        add_filter('quizify_max_questions_per_quiz', array($this, 'get_max_questions_per_quiz'));
        add_filter('quizify_max_options_per_question', array($this, 'get_max_options_per_question'));
    }
    
    /**
     * Get if Pro version is active
     * 
     * @return bool True if pro is active
     */
    public static function is_pro() {
        // Check if development mode is enabled (always true in that case)
        if (defined('QUIZIFY_DEV_MODE') && QUIZIFY_DEV_MODE) {
            return true;
        }
        
        // Otherwise check if the option is set
        return get_option('quizify_is_pro', false);
    }
    
    /**
     * Return max quizzes limit
     * 
     * @return int Max quizzes limit
     */
    public function get_max_quizzes() {
        return self::is_pro() ? -1 : self::MAX_FREE_QUIZZES;
    }
    
    /**
     * Return max questions per quiz limit
     * 
     * @return int Max questions per quiz limit
     */
    public function get_max_questions_per_quiz() {
        return self::is_pro() ? -1 : self::MAX_FREE_QUESTIONS;
    }
    
    /**
     * Return max options per question limit
     * 
     * @return int Max options per question limit
     */
    public function get_max_options_per_question() {
        return self::is_pro() ? -1 : self::MAX_FREE_OPTIONS;
    }
    
    /**
     * Check if there's an allowed quota left for new quizzes
     * 
     * @return bool True if quota available
     */
    public static function has_quiz_quota() {
        // Pro version has unlimited quizzes
        if (self::is_pro()) {
            return true;
        }
        
        // Free version check against the limit
        global $wpdb;
        $table_name = $wpdb->prefix . 'quizify_quizzes';
        
        // Get the count of existing quizzes
        $quiz_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE is_deleted = 0");
        
        // Return true if under the limit
        return ($quiz_count < self::MAX_FREE_QUIZZES);
    }
    
    /**
     * Enqueue variables for the frontend with feature flags
     */
    public function enqueue_feature_vars() {
        // Only on quiz edit page
        global $pagenow;
        
        if (($pagenow === 'admin.php' && isset($_GET['page']) && ($_GET['page'] === 'quizify_admin' || $_GET['page'] === 'quizify_add_quiz')) || 
            ($pagenow === 'admin.php' && isset($_GET['page']) && isset($_GET['action']) && $_GET['page'] === 'quizify_admin' && $_GET['action'] === 'edit')) {
            
            // Add inline script with feature vars
            wp_localize_script('quizify-admin', 'quizify_features', array(
                'is_pro' => self::is_pro(),
                'question_limit' => $this->get_max_questions_per_quiz(),
                'options_limit' => $this->get_max_options_per_question(),
                'quizzes_limit' => $this->get_max_quizzes(),
                'has_quiz_quota' => self::has_quiz_quota(),
                'quizzes_used' => $this->get_used_quiz_count(),
                'quizzes_remaining' => $this->get_remaining_quiz_count(),
                'premium_types' => array('text', 'paragraph', 'true_false', 'matching', 'fill_blanks'),
                'free_types' => array('single', 'multiple'),
            ));
        }
    }
    
    /**
     * Get the number of quizzes already created
     * 
     * @return int Quiz count
     */
    public function get_used_quiz_count() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'quizify_quizzes';
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE is_deleted = 0");
    }
    
    /**
     * Get the number of quizzes that can still be created
     * 
     * @return int Remaining quiz count
     */
    public function get_remaining_quiz_count() {
        if (self::is_pro()) {
            return -1; // Unlimited
        }
        
        $used = $this->get_used_quiz_count();
        $remaining = self::MAX_FREE_QUIZZES - $used;
        return max(0, $remaining);
    }
    
    /**
     * Show an upgrade notice when relevant
     */
    public function show_upgrade_notice() {
        // Only on quiz edit page and only in free version
        global $pagenow;
        
        if (!self::is_pro() && 
            (($pagenow === 'admin.php' && isset($_GET['page']) && $_GET['page'] === 'quizify_admin') ||
             ($pagenow === 'admin.php' && isset($_GET['page']) && $_GET['page'] === 'quizify_add_quiz'))) {
            
            // Check if quota is running low
            $remaining = $this->get_remaining_quiz_count();
            if ($remaining <= 1) {
                // Show warning
                ?>
                <div class="notice notice-warning quizify-upgrade-notice is-dismissible">
                    <h3><span class="dashicons dashicons-warning"></span> Quizify Free Version Limits</h3>
                    <p>You have <strong><?php echo $remaining; ?></strong> <?php echo $remaining === 1 ? 'quiz' : 'quizzes'; ?> remaining in the free version. 
                       Upgrade to Quizify Pro for unlimited quizzes and access to all premium features!</p>
                    <a href="?page=quizify_license" class="button button-primary quizify-upgrade-link">Upgrade to Pro</a>
                </div>
                <?php
            }
        }
    }
    
    /**
     * Restrict admin tabs in free version
     * 
     * @param array $tabs Admin tabs
     * @return array Modified tabs
     */
    public function restrict_admin_tabs($tabs) {
        if (!self::is_pro()) {
            // Check if analytics tab exists, if so replace with upgrade tab
            if (isset($tabs['analytics'])) {
                $tabs['analytics'] = array(
                    'label' => 'Analytics <span class="quizify-pro-badge">PRO</span>',
                    'callback' => array($this, 'render_upgrade_tab'),
                );
            }
            
            // Check if explanation tab exists, if so replace with upgrade tab
            if (isset($tabs['explanations'])) {
                $tabs['explanations'] = array(
                    'label' => 'Explanations <span class="quizify-pro-badge">PRO</span>',
                    'callback' => array($this, 'render_upgrade_tab'),
                );
            }
        }
        
        return $tabs;
    }
    
    /**
     * Render upgrade tab content
     */
    public function render_upgrade_tab() {
        ?>
        <div class="quizify-upgrade-tab-content">
            <div class="quizify-card">
                <h2><span class="dashicons dashicons-lock"></span> Premium Feature</h2>
                <p>This feature is only available in the Pro version. Upgrade to Quizify Pro to unlock:</p>
                <ul class="quizify-feature-list">
                    <li><span class="dashicons dashicons-yes"></span> Advanced question types (Text, Paragraph, True/False, etc.)</li>
                    <li><span class="dashicons dashicons-yes"></span> Detailed quiz analytics and reporting</li>
                    <li><span class="dashicons dashicons-yes"></span> Explanation support for questions</li>
                    <li><span class="dashicons dashicons-yes"></span> Unlimited quizzes and questions</li>
                    <li><span class="dashicons dashicons-yes"></span> Priority support</li>
                </ul>
                <a href="?page=quizify_license" class="button button-primary quizify-upgrade-link">Upgrade Now</a>
            </div>
        </div>
        <style>
            .quizify-upgrade-tab-content {
                max-width: 800px;
                margin: 20px auto;
            }
            .quizify-card {
                background: #fff;
                border-radius: 5px;
                padding: 25px;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                text-align: center;
            }
            .quizify-card h2 {
                color: #2271b1;
                font-size: 24px;
                margin-top: 0;
            }
            .quizify-card p {
                font-size: 16px;
                margin-bottom: 20px;
            }
            .quizify-feature-list {
                list-style: none;
                padding: 0;
                margin: 0 0 25px;
                text-align: left;
                display: inline-block;
            }
            .quizify-feature-list li {
                margin-bottom: 12px;
                font-size: 15px;
            }
            .quizify-feature-list .dashicons {
                color: #4CAF50;
                margin-right: 8px;
            }
            .quizify-upgrade-link {
                font-size: 16px !important;
                padding: 8px 20px !important;
                height: auto !important;
            }
            .quizify-pro-badge {
                background: #ff6b6b;
                color: white;
                padding: 2px 6px;
                border-radius: 3px;
                font-size: 11px;
                font-weight: bold;
                vertical-align: middle;
            }
        </style>
        <?php
    }
    
    /**
     * Enforce quiz limits on save
     * 
     * @param array $quiz_data Quiz data
     * @param int $quiz_id Quiz ID
     * @return array Modified quiz data
     */
    public function enforce_quiz_limits($quiz_data, $quiz_id) {
        // Only apply to free version
        if (!self::is_pro()) {
            // Check if quiz data contains questions
            if (isset($quiz_data['questions']) && is_array($quiz_data['questions'])) {
                // Limit to max free questions
                if (count($quiz_data['questions']) > self::MAX_FREE_QUESTIONS) {
                    $quiz_data['questions'] = array_slice($quiz_data['questions'], 0, self::MAX_FREE_QUESTIONS);
                }
                
                // Loop through each question to enforce option limits
                foreach ($quiz_data['questions'] as $key => $question) {
                    // Limit to free question types
                    if (isset($question['type']) && !in_array($question['type'], array('single', 'multiple'))) {
                        $quiz_data['questions'][$key]['type'] = 'single';
                    }
                    
                    // Limit options per question
                    if (isset($question['options']) && is_array($question['options'])) {
                        if (count($question['options']) > self::MAX_FREE_OPTIONS) {
                            $quiz_data['questions'][$key]['options'] = array_slice($question['options'], 0, self::MAX_FREE_OPTIONS);
                        }
                    }
                }
            }
        }
        
        return $quiz_data;
    }
    
    /**
     * Restrict question types in free version
     * 
     * @param array $types Question types
     * @return array Filtered question types
     */
    public function restrict_question_types($types) {
        // Only apply to free version
        if (!self::is_pro()) {
            // Free version only supports single and multiple choice
            $free_types = array();
            
            // Loop through types and keep only free ones
            foreach ($types as $type => $label) {
                if (in_array($type, array('single', 'multiple'))) {
                    $free_types[$type] = $label;
                } else {
                    // Add PRO indicator to premium types
                    $free_types[$type] = $label . ' <span class="quizify-pro-badge">PRO</span>';
                }
            }
            
            return $free_types;
        }
        
        return $types;
    }
}